# Último Refugio – proyecto Android Studio (v12: con anuncios y compras)

> **Novedades v87 / app 8.1: MODO ASEDIO (oleadas sin fin), final del helicóptero DURO (v86), flecha hacia la señal y helicóptero grande. Lee `CAMBIOS_v87.md` y `CAMBIOS_v86.md`.**

> **Para publicar en Google Play lee primero `PLAY_STORE_GUIA.md`** (IDs de AdMob, productos de compra, política de privacidad `privacy.html`).
> Los IDs de AdMob que vienen son de PRUEBA. Se cambian con variables de entorno / secretos (`ADMOB_APP_ID`, `ADMOB_REWARDED`, `ADMOB_INTERSTITIAL`, `PRIVACY_URL`), sin editar código; ver `PLAY_STORE_GUIA.md`.

El juego completo (con las fuentes incluidas, funciona sin internet) está en
`app/src/main/assets/index.html` y se muestra en un WebView a pantalla completa.
Las partidas se guardan solas (localStorage).

## Requisitos
- Android Studio **Ladybug / Meerkat (2024.3 o más nuevo)** (usa JDK 17 incluido).
- Conexión a internet la primera vez (descarga Gradle 8.11.1, el SDK 36 y las librerías de AdMob / Play Billing).

## Pasos para sacar el APK
1. Descomprime `UltimoRefugio_Android.zip`.
2. Android Studio → **File ▸ Open** → elige la carpeta `UltimoRefugio_Android` (la que contiene `settings.gradle`).
3. Espera a que termine "Gradle Sync". Si pide instalar **Android SDK Platform 36**, acepta (aparece un enlace "Install" en el aviso).
4. Prueba: conecta tu celular con **Depuración USB** activada (o crea un emulador) y pulsa ▶ **Run**.
5. APK de prueba: menú **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**. Cuando termine, pulsa "locate" en la notificación:
   `app/build/outputs/apk/debug/app-debug.apk`. Pásalo al celular e instálalo (permite "instalar apps de origen desconocido").

## APK/AAB firmado (para publicar en Google Play)
1. **Build ▸ Generate Signed Bundle / APK…**
2. Elige **Android App Bundle** (Play Store) o **APK**.
3. **Create new…** para crear tu llave (keystore): guarda el archivo `.jks` y sus contraseñas en un lugar seguro. Si la pierdes no podrás actualizar la app.
4. Selecciona **release** ▸ Finish. Saldrá en `app/release/` (APK) o `app/release/*.aab` (bundle).
5. Para Play Store sube el `.aab` en la Play Console. El icono de 512×512 está en `icono_play_store_512.png`.

## Cambios útiles
- **Nombre de la app:** `app/src/main/res/values/strings.xml`.
- **Id del paquete:** `applicationId` en `app/build.gradle` (cámbialo por el tuyo, p. ej. `com.impulsocapital.ultimorefugio`).
- **Versión:** `versionCode` / `versionName` en `app/build.gradle` (súbelos en cada actualización).
- **Orientación:** el juego es horizontal (`sensorLandscape`: funciona con el celular girado a cualquier lado). Para cambiarla edita `android:screenOrientation` en `AndroidManifest.xml`.
- **Actualizar el juego:** reemplaza `app/src/main/assets/index.html` por la nueva versión y compila de nuevo.
  (Si el nuevo archivo carga fuentes de Google, quita ese `<link>` y deja las fuentes incrustadas, o sin internet usará otra tipografía).

## Si algo falla
- *"Unsupported Gradle/AGP"*: actualiza Android Studio, o en **File ▸ Settings ▸ Build ▸ Gradle** usa "Gradle JDK = 17".
- *Pantalla en blanco*: comprueba que `assets/index.html` existe y no esté vacío.
- *No guarda la partida*: no desactives "Almacenamiento" ni borres datos de la app.
- El botón Atrás del celular pausa el juego; estando en pausa o en el menú, cierra la app.
