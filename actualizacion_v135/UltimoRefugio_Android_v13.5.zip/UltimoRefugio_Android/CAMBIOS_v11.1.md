# Último Refugio Android — Cambios de la versión 11.1

## Torre de guardia reforzada

- Se puede reforzar una torre existente con **2 placas de acero y 6 clavos**.
- La mejora eleva la resistencia máxima de **240 a 360 HP** y suma hasta **120 HP actuales** al terminar.
- Mientras el jugador está arriba, la bonificación de daño pasa de **+25 % a +35 %**.
- Se añade un acabado pixelado con abrazaderas y placas metálicas en la torre reforzada.

## Compatibilidad de partidas

- Se reutiliza la quinta columna ya existente en `baseSave` para guardar el nivel de la torre; no se crea una nueva clave de almacenamiento.
- Las partidas anteriores, cuyo nivel de torre era `0`, se cargan como torres normales de 240 HP.
- La torre reforzada se guarda con nivel `1` y restaura su máximo de 360 HP al cargar.
- Se mantienen `SAVEKEY`, `OPTKEY`, `baseSave` como arreglo, inventarios y demás estructuras existentes; únicamente se amplía el valor opcional de la quinta columna para torres.
- Se conserva el identificador `com.impulso.ultimorefugio`.

## Pruebas ejecutadas

- Sintaxis de los bloques JavaScript embebidos con `node --check`.
- Prueba aislada de la función de refuerzo y serialización/carga de torres normales y reforzadas.
- XML de Android parseado y metadatos de versión comprobados.
- Integridad del ZIP y comparación de archivos no modificados.

## Pendiente

No se compiló APK/AAB ni se midió FPS en dispositivo: este entorno no dispone de Android SDK/Gradle ni de un teléfono conectado. Se recomienda probar una partida anterior, reforzar una torre, guardar, cerrar y volver a cargar; también comprobar combate desde la torre y daños de zombis a la estructura.
