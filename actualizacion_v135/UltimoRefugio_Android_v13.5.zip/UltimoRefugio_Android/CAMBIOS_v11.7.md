# Último Refugio Android 11.7

## Mejoras de rendimiento

- Se añade una caché escalonada de línea de visión para NPC. La caché se invalida al cambiar la media casilla del jugador o del superviviente y dura entre 140 y 176 ms. Esto reduce raycasts repetidos en zonas con muchos NPC.
- Se añade nivel de detalle para animaciones de NPC: 16 fases cerca, 8 a distancia media y 4 a distancia lejana o en calidad baja. No cambia la IA ni la frecuencia de actualización de los NPC.
- Las sombras detalladas de NPC se dibujan únicamente en calidad normal/alta y a menos de 8 casillas; se mantiene la sombra básica de sprite para preservar la lectura espacial.
- Los indicadores de daño de NPC y vehículos usan el reloj compartido del fotograma, evitando consultas individuales al reloj del sistema.

## Conservación de sistemas

- No se cambia el esquema de guardado, las claves de almacenamiento ni el protocolo multijugador.
- No se alteran daño, combate, movimiento, selección de objetivos ni simulación de zombis.
- Se conserva el estilo isométrico pixel art.

## Versión Android

- `versionCode`: 109
- `versionName`: 11.7

## Validación

La validación estática debe incluir sintaxis JavaScript, XML Android e integridad del ZIP. No se afirma compilación APK ni medición de FPS real sin Android SDK/Gradle y dispositivo de prueba.
