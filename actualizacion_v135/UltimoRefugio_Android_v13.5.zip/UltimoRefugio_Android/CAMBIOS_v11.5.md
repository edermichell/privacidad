# Último Refugio Android 11.5

## Gráficos
- La lluvia ahora varía la longitud y la deriva de las gotas según el viento visual y la intensidad de tormenta.
- Las tormentas fuertes agregan una segunda capa ligera de gotas cercanas.
- La nieve incorpora deriva lateral y movimiento ambiental más coherente.
- Los efectos de precipitación reducen o recuperan su densidad de forma gradual según el tiempo real de trabajo del fotograma (`PERF.fxScale`).
- El estilo pixel art, el búfer de resolución y el sistema de iluminación nocturna de 11.4 se mantienen.

## Rendimiento
- Nuevo pool de hasta 320 objetos de partículas reutilizables para sangre, polvo, chispas, humo, casquillos, hojas, nieve ambiental y otros efectos.
- La actualización de partículas ya no hace `splice()` por cada partícula expirada: compacta la lista con `copyWithin()` en una sola operación estable.
- La compactación conserva el orden original de dibujo y el orden inverso de consumo aleatorio de la versión anterior.
- Al reiniciar el mundo, las partículas activas se devuelven al pool cuando hay espacio.
- La escala adaptativa afecta únicamente a efectos decorativos; no cambia IA, daño, frecuencia de ataques, física, economía ni simulación de zombis.

## Compatibilidad
- Se conservan `SAVEKEY`, `OPTKEY`, `buildSave`, `applySave`, `baseSave` y `baseLoad`.
- El identificador de aplicación continúa siendo `com.impulso.ultimorefugio`.
- `versionName`: `11.5`; `versionCode`: `107`.

## Validaciones realizadas
- Los dos bloques JavaScript embebidos pasan `node --check`.
- Los cuatro XML de Android pasan parseo.
- Prueba diferencial determinista entre 11.4 y 11.5: 180 ciclos de actualización y 13 tipos de partículas; el estado visible y el generador aleatorio coinciden.
- Prueba de reciclaje: las partículas expiradas regresan al pool y se reutilizan en los siguientes efectos.
- Prueba aislada de nieve: el viento modifica la deriva y el escalado adaptativo reduce la densidad de 104 a 57 copos en el escenario de prueba.
- Comparación de archivos: solamente cambian `index.html`, `app/build.gradle` y este registro de cambios.
- ZIP comprobado por integridad.

## Pendiente
No se compiló APK/AAB ni se midió FPS en un dispositivo físico. En este entorno no hay Gradle instalado ni Android SDK configurado; el rendimiento real debe medirse en teléfonos Android.
