# Último Refugio 13.2.2 — mantenimiento y optimización

## Alcance

Actualización de mantenimiento sobre 13.2.1. **No añade objetos, enemigos, efectos, recetas, misiones ni mecánicas.** No cambia el equilibrio, las reglas de combate, la navegación ni el formato de las partidas.

## Optimizaciones

1. **Renderizado:** se movió fuera de `render()` la función que inserta entidades en los buckets y el marcador de fases. Se evita crear dos cierres por fotograma; ambos utilizan helpers compartidos y mantienen los mismos parámetros y operaciones.
2. **Visibilidad de zombis:** el render reutiliza la distancia al cuadrado que ya calcula para el descarte temprano y elimina una llamada redundante a `Math.hypot` por zombi evaluado.
3. **Cadáveres:** los filtros de distancia de cadáveres de zombis y NPC usan comparación de distancias al cuadrado, sin calcular raíces cuadradas.
4. **NPC:** las etiquetas y el indicador de proximidad comparan umbrales al cuadrado y evitan una raíz cuadrada que solo se utilizaba para dos comparaciones.
5. **Búsqueda de amenazas:** la versión final de `npcThreat` recorría el índice espacial mediante un callback por consulta. Ahora recorre directamente los mismos buckets, en el mismo orden, conservando los filtros de estado, desempates, comprobaciones de línea de visión y objetivo elegido.
6. **Fauna/combate existente:** las comprobaciones de radio de atracción de zombis, mordidas y daño por fuego usan distancias al cuadrado. Se mantienen los radios y comparaciones estrictas/inclusivas.
7. **Opacidad de edificios:** las cuatro posiciones diagonales usadas para atenuar techos se calculan una vez por fotograma, no dentro del bucle de cada edificio. Se mantiene la secuencia acumulativa original de pasos de 0.8.
8. **Diagnóstico:** se corrigió el encabezado que todavía identificaba el informe como 12.8; ahora informa 13.2.2. No se incorporan indicadores nuevos.

## Compatibilidad

- `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()` no se modifican.
- No se añaden propiedades serializables a jugadores, NPC, zombis ni animales.
- Identificador Android y recursos nativos conservados.
- `versionName`: `13.2.2`.
- `versionCode`: `127`.

## Validaciones realizadas

- Los dos bloques JavaScript embebidos pasan `node --check`.
- Cuatro archivos XML se pueden parsear.
- Comparación diferencial de la búsqueda de amenazas: 5,000 escenarios aleatorios; mismo objetivo y distancia.
- Comparación de los cuatro puntos de atenuación de techos: 200,000 casos; mismo resultado.
- Comparación de umbrales de distancia: 200,000 casos aleatorios/borde.
- Reutilización del helper de buckets: 100,000 inserciones; mismas claves, orden y entradas.
- Prueba adicional de radios de daño: 250,000 casos; mismo resultado.
- La inicialización temprana de `TIME` y el arreglo de `Q` de 13.2.1 permanecen presentes.
- El HTML de prueba es idéntico al `app/src/main/assets/index.html` del proyecto.
- Integridad del ZIP comprobada.

## Pendiente

No se pudo completar el arranque automatizado en Chromium en este entorno porque el navegador devuelve `ERR_BLOCKED_BY_ADMINISTRATOR` tanto para `file://` como para `127.0.0.1`. No se compiló APK/AAB: no hay Android SDK/Gradle disponibles. Por ello no se atribuyen mejoras de FPS sin medirlas en un dispositivo real.
