# Último Refugio Android 11.0

## Objetivo

Dar más mantenimiento y legibilidad táctica a las defensas de base sin introducir un sistema de guardado nuevo ni aumentar el trabajo permanente del bucle de simulación.

## Cambios incluidos

- **Reparar trampas de pinchos:** una defensa dañada puede recuperar hasta 7 usos por reparación, consumiendo 1 tablón y 4 clavos.
- **Reparar alarmas de botellas:** una alarma dañada puede recuperar hasta 4 avisos, consumiendo 1 botella y 1 trapo.
- **Indicador de resistencia:** las trampas y alarmas dañadas muestran una pequeña barra pixelada; el color cambia según la resistencia restante. No se dibuja para estructuras intactas.
- **Interacción contextual:** al acercarse a una defensa dañada, la acción normal pasa a ser repararla. En modo sigilo se conserva la acción existente de desmontar.
- **Balance y seguridad:** las reparaciones vuelven a comprobar materiales y que la estructura siga colocada al terminar la acción; la resistencia nunca supera su máximo.
- **Compatibilidad de partidas:** se reutilizan los campos `hp` y `mhp` ya existentes. No se cambia `baseSave`, `baseLoad`, `SAVEKEY`, `OPTKEY`, el formato de `bs`, el identificador de aplicación ni el protocolo multijugador.
- **Versión Android:** `versionCode` 102 y `versionName` 11.0.

## Validaciones realizadas

- Sintaxis de los dos bloques JavaScript embebidos comprobada con Node.js.
- Pruebas aisladas de selección contextual, desmontaje en sigilo, falta de materiales, consumo correcto, reparación parcial, límite máximo de resistencia y barras de durabilidad.
- Parseo correcto de los cuatro archivos XML Android.
- Verificación de `applicationId`, `versionCode` y `versionName`.
- Comparación con 10.9: fuera del HTML principal, del archivo Gradle de versión y de este registro, los archivos del proyecto permanecen iguales.
- Verificación de que las funciones y claves de guardado mantienen el formato de 10.9.
- Integridad del ZIP comprobada.
- No se ejecutó compilación APK/AAB ni prueba en un dispositivo físico: este entorno no tiene Android SDK/Gradle instalados.

## Qué probar en dispositivo

1. Coloca una trampa de pinchos y deja que dañe zombis hasta perder usos; acércate y confirma que aparece la opción de reparación.
2. Repara con 1 tablón y 4 clavos; comprueba que aumenta la resistencia sin superar el máximo.
3. Repite con una alarma de botellas usando 1 botella y 1 trapo.
4. Intenta reparar sin materiales: la acción debe rechazarse sin consumir nada.
5. Entra en sigilo junto a una defensa dañada y confirma que sigue apareciendo la opción de desmontarla.
6. Guarda y carga la partida: las resistencias de las defensas deben mantenerse.
7. Repite en cooperativo como anfitrión y como invitado para confirmar que la autoridad del anfitrión y la sincronización existente permanecen iguales.
