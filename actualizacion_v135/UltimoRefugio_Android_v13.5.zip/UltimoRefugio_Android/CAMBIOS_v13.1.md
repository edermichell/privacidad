# Último Refugio 13.1 — simulación LOD segura y dibujo distante

## Objetivo
Reducir trabajo de CPU en campamentos y hordas numerosas sin reducir poblaciones ni alterar combate, movimiento de corto alcance o persistencia.

## Cambios

- Se introduce LOD de simulación escalonado con acumulación de `dt` en `WeakMap`, sin campos nuevos en NPC o zombis guardados.
- Civiles tranquilos no hostiles, sin seguimiento, trabajo, escolta, misión, conversación, ataque o estado de combate: a más de 20 casillas se procesan cada 2 ticks; a más de 40 casillas cada 3 ticks.
- Caminantes comunes en estado `wander`, sin fuego, aturdimiento ni embestida: a más de 18 casillas se procesan cada 2 ticks; a más de 35 casillas cada 3 ticks.
- Se conservan los casos anteriores de LOD para entidades no incluidas en estos grupos, y se excluye el host cuando hay jugador remoto conectado.
- Dibujo simplificado de civiles en estado idle/wander, sin ruta ni alerta activa a más de 14 casillas: omite el `drawSplit` y el balanceo idle; conserva el sprite, orientación, nivel de animación, etiquetas, indicadores y posición.
- F2 informa actualizaciones completas/agrupadas/omitidas y NPC dibujados en modo completo/simple.

## Seguridad de compatibilidad

- El estado de los acumuladores reside en `WeakMap`; no se añaden propiedades serializables a NPC ni zombis.
- No se modifican `SAVEKEY`, `OPTKEY`, `baseSave`, `baseLoad`, recetas, daño, munición, IA de combate ni protocolos de red.
- Se conserva el arreglo de arranque de 12.4.1 (`TIME` declarada antes de vistas previas) y la señal de error de arranque.
- `versionName 13.1`, `versionCode 124`.

## Validación

- Pendiente de ejecución automatizada completa de Chromium y de compilación en Android SDK/Gradle en este entorno.
- Se ejecutarán comprobaciones sintácticas y pruebas aisladas de equivalencia temporal, exclusiones de estados activos y persistencia antes de distribuir el paquete.

## Validación final

- Los dos bloques JavaScript embebidos pasan `node --check`.
- Los cuatro XML del proyecto Android se parsean correctamente.
- Prueba de arranque en Chromium sobre el HTML completo: menú visible, `window.__UR_BOOT_OK === true`, nueva partida en estado `play`, panel F2 abre correctamente y no se detectaron errores de página ni de consola.
- Pruebas sintéticas del planificador: NPC cercanos y NPC con ruta activa mantienen actualización completa; civiles tranquilos y lejanos usan los intervalos 2/3; los NPC hostiles conservan el comportamiento anterior; el host con jugador remoto queda excluido del nuevo LOD; caminantes comunes lejanos usan intervalos 2/3 y los zombis especiales conservan su actualización anterior.
- Se verificó que `SAVEKEY`, `OPTKEY`, `baseSave` y `baseLoad` mantienen sus definiciones originales.
- El HTML de prueba se copia byte por byte desde `app/src/main/assets/index.html`.
- No se compiló APK/AAB: este entorno no dispone de Android SDK ni Gradle instalados. Tampoco se han medido FPS en un dispositivo físico.
