# Último Refugio 12.6 — Cambios

## Objetivo
Reducir asignaciones temporales en la IA de NPC y añadir métricas específicas de consultas a zombis, sin cambiar la selección de objetivos, el daño, la frecuencia de detección ni el formato de partidas.

## Cambios

### IA y rendimiento
- `npcThreat`, `npcZombieAttract` y `npcZombieBites` ahora recorren directamente las mismas celdas del índice espacial en lugar de crear una función callback por consulta.
- Se conserva exactamente el orden de recorrido de celdas y de los zombis dentro de cada bucket.
- Se conservan los filtros de estado, distancias, línea de visión, temporizadores y aplicación de daño.
- No se modifica el ritmo de escaneo ni se ralentizan compañeros, NPC hostiles o civiles.

### Diagnóstico F2
- Añade contadores de escaneos de amenaza, atracción y mordida.
- Añade candidatos examinados por cada consulta y mordidas aplicadas.
- Los contadores solo se incrementan cuando el diagnóstico está abierto.
- El botón Reiniciar también reinicia estos contadores.

### Compatibilidad
- Se conserva la inicialización temprana de `TIME` para evitar el error de pantalla negra de versiones anteriores.
- Se conservan `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()`.
- No se modifican archivos nativos Android ni el esquema de guardado.
- El HTML web es byte por byte idéntico al `index.html` de Android.

## Validaciones realizadas
- Sintaxis JavaScript de scripts inline validada con Node.
- XML Android parseados correctamente.
- Comparación diferencial de las consultas antiguas con las nuevas sobre datos sintéticos aleatorios (amenaza, atracción y mordidas).
- Comparación de selección de objetivos y efectos laterales con orden de celdas idéntico.
- Verificación de `TIME` antes de la vista previa del menú.
- Verificación de claves de guardado y versión Android.
- Integridad del ZIP comprobada.

## Pendiente
No se compiló APK/AAB ni se realizó medición de FPS en dispositivo real. La mejora reduce callbacks y asignaciones asociadas a consultas de IA; su impacto real debe medirse en el campamento habitual con F2.
