# Último Refugio – proyecto Android Studio (v10.0: con anuncios y compras)

> **Para publicar en Google Play lee primero `PLAY_STORE_GUIA.md`** (Unity Ads, productos de compra, política de privacidad `privacy.html`).
> v103: AdMob eliminado. Los anuncios son **solo de Unity Ads y REALES por defecto** (`UNITY_TEST_MODE=false`). Se configuran con variables de entorno / secretos (`UNITY_GAME_ID`, `UNITY_REWARDED`, `UNITY_INTERSTITIAL`, `UMP_APP_ID`, `PRIVACY_URL`), sin editar código; ver `PLAY_STORE_GUIA.md`.

El juego completo (con las fuentes incluidas, funciona sin internet) está en
`app/src/main/assets/index.html` y se muestra en un WebView a pantalla completa.
Las partidas se guardan solas (localStorage).

## Requisitos
- Android Studio **Ladybug / Meerkat (2024.3 o más nuevo)** (usa JDK 17 incluido).
- Conexión a internet la primera vez (descarga Gradle 8.11.1, el SDK 36 y las librerías de Unity Ads / Play Billing).

## Pasos para sacar el APK
1. Descomprime `UltimoRefugio_Android.zip`.
2. Android Studio → **File ▸ Open** → elige la carpeta `UltimoRefugio_Android` (la que contiene `settings.gradle`).
3. Espera a que termine "Gradle Sync". Si pide instalar **Android SDK Platform 36**, acepta (aparece un enlace "Install" en el aviso).
4. Prueba: conecta tu celular con **Depuración USB** activada (o crea un emulador) y pulsa ▶ **Run**.
5. APK de prueba: menú **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**. Cuando termine, pulsa "locate" en la notificación:
   `app/build/outputs/apk/debug/app-debug.apk`. Pásalo al celular e instálalo (permite "instalar apps de origen desconocido").

## APK/AAB firmado (para publicar en Google Play)
1. **Build ▸ Generate Signed Bundle / APK…**
2. Elige **Android App Bundle** (Play Store) o **APK**.
3. **Create new…** para crear tu llave (keystore): guarda el archivo `.jks` y sus contraseñas en un lugar seguro. Si la pierdes no podrás actualizar la app.
4. Selecciona **release** ▸ Finish. Saldrá en `app/release/` (APK) o `app/release/*.aab` (bundle).
5. Para Play Store sube el `.aab` en la Play Console. El icono de 512×512 está en `icono_play_store_512.png`.

## Novedades de v10.0
- Calidad automática que baja efectos bajo carga y recupera detalle al estabilizarse.
- Caché de terreno y estructuras de render con menor presión de memoria y asignaciones.
- Se conserva el formato de guardado y el identificador de aplicación.
- Consulta `CAMBIOS_v10.0.md` para el detalle y las pruebas pendientes antes de publicar.

## Cambios útiles
- **Nombre de la app:** `app/src/main/res/values/strings.xml`.
- **Id del paquete:** `applicationId` en `app/build.gradle` (cámbialo por el tuyo, p. ej. `com.impulsocapital.ultimorefugio`).
- **Versión:** `versionCode` / `versionName` en `app/build.gradle` (súbelos en cada actualización).
- **Orientación:** el juego es horizontal (`sensorLandscape`: funciona con el celular girado a cualquier lado). Para cambiarla edita `android:screenOrientation` en `AndroidManifest.xml`.
- **Actualizar el juego:** reemplaza `app/src/main/assets/index.html` por la nueva versión y compila de nuevo.
  (Si el nuevo archivo carga fuentes de Google, quita ese `<link>` y deja las fuentes incrustadas, o sin internet usará otra tipografía).

## Si algo falla
- *"Unsupported Gradle/AGP"*: actualiza Android Studio, o en **File ▸ Settings ▸ Build ▸ Gradle** usa "Gradle JDK = 17".
- *Pantalla en blanco*: comprueba que `assets/index.html` existe y no esté vacío.
- *No guarda la partida*: no desactives "Almacenamiento" ni borres datos de la app.
- El botón Atrás del celular pausa el juego; estando en pausa o en el menú, cierra la app.


## Versión 10.1

Esta entrega incorpora reutilización de entradas temporales del renderizado. Consulta `CAMBIOS_v10.1.md` para el detalle y las pruebas recomendadas.


## Versión 10.2

Esta entrega mejora la lectura de blancos en combate: el apuntado y los golpes cuerpo a cuerpo respetan la línea de visión, incluso si el enemigo se mueve durante la animación de ataque. También se evita concatenar las listas de entidades en cada perdigón disparado. Consulta `CAMBIOS_v10.2.md` para el detalle y las pruebas recomendadas.


## Versión 10.3

Esta versión mantiene rápida la percepción cerca del jugador y reduce la frecuencia de consultas de visión para zombis lejanos, además de espaciar el recálculo de rutas bajo presión de hordas. También refuerza la línea de visión para ataques de zombis contra jugadores/NPC y para el combate cuerpo a cuerpo de compañeros. Consulta `CAMBIOS_v10.3.md` para el detalle y las pruebas recomendadas.
