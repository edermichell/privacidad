# Último Refugio 12.9 — cambios técnicos

## Objetivo
Reducir trabajo de CPU y asignación de cadenas durante el renderizado de zombis y supervivientes, sin cambiar el sprite resultante, el orden de dibujo, la lógica de juego ni el formato de guardado.

## Implementación
- `humanSprite()` consulta ahora `humanKeyMemo129()` en vez de concatenar siempre los ~25 campos de la clave.
- Una `WeakMap` conserva, por objeto de especificación, una instantánea normalizada de los campos visuales y la última clave generada.
- Cuando orientación, frame, pose, equipo, paleta, heridas, escala u otro campo visual no cambia, se devuelve la cadena almacenada.
- Si cualquiera de esos campos cambia, se reconstruye la clave mediante la función original `humanKey()`.
- La WeakMap no retiene entidades eliminadas y no añade propiedades serializables a NPC o zombis.
- F2 informa aciertos de memoización y reconstrucciones de clave.

## Medición aislada
Microbenchmark Node/V8 con 250 objetos de especificación, 1,200 ciclos por objeto (300,000 consultas), y un cambio de frame cada ocho ciclos:
- Clave original: 66.56 ms.
- Clave memoizada: 40.13 ms.
- Aceleración en esa prueba sintética: 1.66×.
- La longitud acumulada de las claves resultantes coincidió exactamente.

Este microbenchmark no es una medición de FPS ni representa necesariamente el rendimiento de Chromium Android/WebView. El beneficio real debe comprobarse con F2 en el mismo campamento y dispositivo.

## Validaciones realizadas
- Ambos bloques JavaScript del HTML pasan `node --check`.
- 600,000 comparaciones diferenciales de claves: memoizada frente a `humanKey()`; sin diferencias.
- Se comprobaron mutaciones de campos visuales y reutilización cuando no hay cambios.
- `build.gradle`: `versionCode 122`, `versionName "12.9"`.
- Cuatro archivos XML Android parseados correctamente.
- HTML de prueba y `app/src/main/assets/index.html` son idénticos byte por byte.
- `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()` se conservaron; no se modificó su código.
- La inicialización temprana de `TIME` y la protección visual de errores de arranque de la 12.4.1 permanecen.
- ZIP comprobado con `unzip -t`.

## Pendiente
No se pudo concluir una prueba de arranque en Chromium en esta sesión: el proceso headless quedó bloqueado antes de devolver el DOM. Tampoco se compiló APK/AAB porque no hay Android SDK/Gradle disponibles en el entorno. No se declaran mejoras de FPS en un teléfono hasta recibir una medición real.
