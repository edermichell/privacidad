# Último Refugio Android 11.9

## Cambios

- `drawParts()` y `drawFlies()` ahora comparten los límites mundo/pantalla del encuadre actual. La inversión de las cuatro esquinas de la cámara se calcula una vez por estado de cámara, no una vez por cada pasada de partículas. Se conserva el filtro exacto de pantalla para evitar falsos descartes.
- Se añadió un panel de diagnóstico activable desde **Ajustes → Gráficos → Diagnóstico avanzado** o con **F2**. Muestra FPS efectivos, tiempo medio/P95/máximo del trabajo de fotograma, número de zombis/NPC/partículas, tamaño de caché de sprites, calidad, resolución de canvas y datos de memoria/dispositivo cuando el navegador los expone.
- El panel utiliza una muestra circular de 120 fotogramas y solo recopila estadísticas mientras está abierto. Incluye botón para copiar el informe.
- No cambia daño, IA, física, recetas, multijugador ni formato de guardado. Las claves `ultimo_refugio_v3` y `ultimo_refugio_opt` permanecen iguales.

## Cómo probar

1. Abrir `app/src/main/assets/index.html` en Chrome o Edge, o abrir `UltimoRefugio_Prueba_v11.9.html`.
2. Iniciar una partida o usar el modo Asedio para generar carga.
3. Abrir Ajustes → Gráficos → Diagnóstico avanzado (o pulsar F2).
4. Esperar unos segundos a que se estabilicen las muestras y usar **COPIAR** para compartir el resultado.

## Validación

- Sintaxis JavaScript: validación con Node.
- XML Android: parseado correctamente.
- ZIP: integridad comprobada.
- HTML de prueba: es el mismo cliente HTML5 autocontenido que usa el WebView Android, con una insignia de prueba web.
- No se compiló APK/AAB porque el entorno no dispone de Android SDK/Gradle. No se midieron FPS reales en un dispositivo físico.
