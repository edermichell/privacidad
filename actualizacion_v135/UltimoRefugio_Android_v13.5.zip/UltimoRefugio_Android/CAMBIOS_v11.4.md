# Último Refugio Android 11.4

## Objetivo

Mejoras conservadoras de renderizado y calidad visual sobre la versión 11.3, manteniendo el estilo pixel art, los sistemas existentes y la estructura de guardado.

## Gráficos

- Aumentada la resolución del búfer interno de iluminación nocturna de 0.50 a 0.60 en calidad normal/alta. La capa se escala suavemente al lienzo principal para definir mejor los halos de farolas, ventanas, fuegos y focos.
- Se conserva el búfer de 0.50 en calidad baja para no penalizar equipos modestos.
- Se mantiene el muestreo sin suavizado de los sprites para preservar el pixel art.

## Rendimiento

- Las tuplas de las 18 rutas que agregan fuentes de luz ahora salen de un pool reutilizable; se dejan de crear arreglos nuevos para las mismas luces en cada fotograma.
- Se filtran por el rectángulo visible de cámara los zombis/NPC y las listas dibujables de objetos del suelo, fuegos, alarmas, proyectiles, barriles, generadores, cultivos, vehículos y jugador remoto antes de introducirlos en los buckets de profundidad.
- La comprobación de visibilidad de NPC usa distancias al cuadrado, evitando llamadas a `Math.hypot` en ese tramo del render.
- El recorte afecta solamente al dibujo; no elimina objetos ni cambia sus actualizaciones de simulación, posiciones, inventarios, daño o IA.

## Compatibilidad

- No se modificaron las claves, estructura ni funciones de serialización de partidas.
- No se modificaron recetas, combate, IA, multijugador ni sistemas de construcción.
- Se conserva el identificador Android.
- `versionCode`: 106.
- `versionName`: 11.4.

## Verificaciones realizadas

- Sintaxis de los dos bloques JavaScript embebidos validada con Node.js.
- Cuatro archivos XML parseados correctamente.
- Prueba aislada del pool: 100 luces por fotograma, sin alias entre entradas y con reutilización de las 100 tuplas en el fotograma siguiente.
- Prueba de cobertura de cámara con 100,000 puntos aleatorios dentro del lienzo: todos quedaron dentro del margen conservador de culling.
- Se comprobó que no quedan llamadas `lights.push([...])` sin migrar.
- ZIP comprobado después de generar el paquete.

## Pendiente

No se compiló APK/AAB ni se midieron FPS, uso de batería o memoria en un dispositivo Android. Las pruebas de pool y cámara son pruebas aisladas; el impacto real debe medirse en teléfonos de distintas gamas.
