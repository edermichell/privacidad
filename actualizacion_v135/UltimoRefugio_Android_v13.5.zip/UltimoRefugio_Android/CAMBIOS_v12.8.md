# Último Refugio 12.8 — cambios técnicos

## Objetivo

Reducir las asignaciones temporales durante el renderizado de grandes grupos de NPC y zombis. La actualización reutiliza las especificaciones visuales por entidad, sin escribir propiedades auxiliares sobre las entidades serializadas ni modificar el formato de guardado.

## Cambios

### Especificaciones visuales de NPC
- `npcSpec()` reutiliza un objeto almacenado en `WeakMap`, en lugar de crear un objeto literal en cada dibujo.
- Todas las propiedades que determinan apariencia, pose, animación y equipo se actualizan en cada llamada.
- Se conserva el orden y las condiciones de pose (`lie`, `atk`, `aim`, `walk`).
- Los wrappers posteriores de LOD y paletas continúan recibiendo y modificando la especificación como antes.

### Especificaciones visuales de zombis
- `zSpec()` reutiliza un objeto por zombi mediante `WeakMap`.
- Se calcula la orientación directamente con seno/coseno, sin crear el objeto temporal que devolvía `faceOf()`.
- Se actualizan explícitamente tipo, ropa, dirección, frame, pose, daño, sangre, escala y estado.

### Orientación de NPC
- `drawNpc()` comparte un objeto temporal de orientación para determinar `front` y `fx`, en vez de crear un objeto nuevo con `faceOf()` para cada NPC dibujado.
- `npcSpec()` copia inmediatamente ambos valores primitivos al objeto asociado al NPC.

### Diagnóstico F2
- Se muestran contadores de especificaciones creadas y reutilizadas para NPC y zombis.
- El informe copiado identifica la versión 12.8.

## Compatibilidad

- No se añaden propiedades a NPC ni zombis: los pools son `WeakMap` externos y no serializables.
- `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()` se conservan sin cambios respecto a 12.7.
- `TIME` continúa inicializada antes de `humanSprite()`, conservando la corrección de pantalla negra 12.4.1.
- Identificador de aplicación conservado.
- `versionName`: `12.8`; `versionCode`: `121`.
- El HTML de prueba web es byte a byte idéntico al `index.html` Android.

## Pruebas realizadas

- Ambos bloques JavaScript pasan `node --check`.
- Prueba diferencial de 84,000 llamadas (160 NPC + 120 zombis durante 300 ciclos): las propiedades que consume el renderizador coincidieron con las funciones originales.
- En esa prueba, las nuevas funciones crearon 280 especificaciones (una por entidad) y reutilizaron 83,720 veces el objeto; el enfoque anterior creaba una especificación en cada llamada. Es una prueba sintética de asignaciones, no una medición de FPS.
- Se verificó que las entidades no reciben nuevos campos serializables.
- Cuatro XML Android pasan parseo.
- Se verificó igualdad entre el HTML web y el asset Android.
- Se compararon claves y funciones de guardado contra 12.7.

## Pendiente

- La ejecución automatizada de Chromium no terminó en el entorno (el proceso headless quedó bloqueado antes de devolver el DOM); no se presenta como prueba de navegador superada.
- No se compiló APK/AAB: no hay Android SDK/Gradle ejecutable disponible.
- No se midió FPS en un teléfono. Se necesita repetir una escena de campamento comparable y revisar los contadores de reutilización y `entityDraw`.
