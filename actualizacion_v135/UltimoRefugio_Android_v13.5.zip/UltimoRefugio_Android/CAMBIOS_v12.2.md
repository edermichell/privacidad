# Último Refugio Android 12.2

## Objetivo

Responder a las mediciones compartidas de la 12.1: 44 FPS efectivos, 13.3 ms de trabajo JavaScript medio, 10.7 ms estimados fuera del trabajo JS, 3,268 expulsiones de sprites y una fase `mundo` que llegó a mostrar 18.6 ms en el informe. La 12.2 mejora la instrumentación para distinguir costes recurrentes de picos aislados, reduce pequeñas asignaciones en el renderizado y ajusta de forma prudente el presupuesto teórico de la caché según la memoria reportada por el dispositivo.

## Cambios

### 1. Estadísticas de fases de render más representativas

- Las fases del renderizado ahora se acumulan en una ventana circular de hasta 180 fotogramas.
- Cada fase informa media, P95 y máximo, en lugar de mostrar solo el último fotograma.
- Se separa la recogida/culling de entidades (`collect`) del dibujo de tiles y entidades (`world`).
- Se separa el dibujo de estructuras (`structures`) de los efectos ambientales.
- Las fases incluyen preparación, terreno, suelo/sombras, recogida, mundo, estructuras, FX, iluminación y composición final.
- La instrumentación solo se activa con el panel de diagnóstico abierto.

Esto aclara una ambigüedad de 12.1: el valor `mundo` que aparecía en el texto era el de una sola muestra, no una media. A partir de 12.2 el informe muestra las tres estadísticas explícitamente.

### 2. Presupuesto de caché de sprites adaptativo

El límite de la caché `HC2` pasa a depender de `navigator.deviceMemory` y de la memoria JS reportada cuando el navegador la ofrece:

- Dispositivo que reporta 8 GB: 72 MB decimales de presupuesto teórico RGBA.
- 4 GB: 64 MB.
- 2 GB: 48 MB.
- 1 GB u otra cifra inferior: 40 MB.
- Memoria no reportada: se conserva el presupuesto anterior de 64 MB.
- Si el heap JS reportado supera 128 MiB: se usa un presupuesto conservador de 56 MB.

En un dispositivo que reporte 8 GB y con RS2, el límite teórico sube aproximadamente de 1,275 a 1,434 sprites (de unos 61.0 a 68.7 MiB RGBA teóricos). Esto podría reducir expulsiones, pero no garantiza una mejora de FPS y no equivale a memoria GPU medida. El sistema sigue creando sprites bajo demanda y expulsando los menos recientes cuando supera el presupuesto.

### 3. Coste de generación de sprites

El diagnóstico ahora registra:
- Número de sprites realmente generados durante la medición.
- Tiempo medio de generación.
- Tiempo máximo de generación.
- Expulsiones por fallo de caché.

Así se puede distinguir una petición no encontrada que usa un fotograma vecino de una generación completa y costosa.

### 4. Menos asignaciones y ordenamientos triviales

- El comparador de orden de dibujo por profundidad se crea una sola vez y se reutiliza.
- Los buckets con cero o una entrada ya no llaman a `sort`, porque no necesitan ordenamiento.
- Se conservan las entradas reutilizables y el mismo orden de dibujo para buckets con múltiples entidades.

## Compatibilidad

- `applicationId`: `com.impulso.ultimorefugio` (sin cambios).
- `versionCode`: `114`.
- `versionName`: `12.2`.
- Se conservan las claves `ultimo_refugio_v3` y `ultimo_refugio_opt`.
- No se cambia el formato de las partidas ni las reglas de daño, IA, movimiento, combate, construcción o multijugador.
- Los archivos nativos Android y recursos se conservan; cambian el HTML principal, `app/build.gradle` y este registro.

## Validaciones

- `node --check` del JavaScript embebido.
- XML Android parseados.
- Prueba Chromium: carga del cliente, inicio de partida, apertura F2, ventana de muestras, informe 12.2 y cierre con Escape.
- Verificación de que el informe contiene medias/P95/máximos de fase, contador de sprites generados y caché adaptativa.
- Prueba con memoria de dispositivo sintética para los niveles de 1, 2, 4 y 8 GB y memoria no reportada.
- Comparación del árbol del proyecto: solo cambian `app/src/main/assets/index.html`, `app/build.gradle` y este archivo.

## Pendiente

No se ha compilado APK/AAB ni medido el rendimiento en un dispositivo Android físico. El entorno no dispone de Android SDK ni Gradle. La ampliación de caché y las optimizaciones de ordenamiento deben contrastarse con nuevas mediciones del mismo escenario en el dispositivo del usuario.
