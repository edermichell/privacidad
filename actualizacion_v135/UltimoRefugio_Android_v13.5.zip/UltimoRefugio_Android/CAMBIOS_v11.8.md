# Último Refugio Android 11.8

## Gráficos: variedad de infectados

- Se añaden cuatro detalles cosméticos deterministas para zombis caminantes y corredores: venda de antebrazo, desgarro de pecho, parche de hombro y correa desgastada.
- Los detalles se hornean en el sprite cacheado, por lo que no añaden llamadas de dibujo por fotograma.
- La variante se deriva del ID de zombi y no requiere guardar campos nuevos; el mismo ID produce el mismo aspecto en anfitrión e invitado.
- Los infectados especiales (blindado, aullador, saltador, tóxico, etc.) conservan su aspecto característico.
- Los golpes críticos generan chispas pixeladas; los impactos contra infectados blindados generan fragmentos. Solo es feedback visual y no altera el daño ni la física.

## Rendimiento: partículas

- `drawParts` y `drawFlies` aplican primero un culling conservador en coordenadas de mundo.
- La proyección isométrica se calcula en línea, evitando crear un arreglo temporal por partícula visible.
- Se conserva el mismo filtro final de pantalla, orden, alfa, tamaño y comportamiento de dibujo para los efectos dentro de la cámara.

## Conservación de sistemas

- No se cambian claves ni formatos de guardado.
- No se altera la IA, el movimiento, el daño, las colisiones, el combate ni el protocolo multijugador.
- La variante cosmética se calcula a partir del ID, sin añadir campos persistentes.
- Se conserva el estilo isométrico pixel art y la compatibilidad con partidas anteriores.

## Versión Android

- `versionCode`: 110
- `versionName`: 11.8

## Validación

- Sintaxis JavaScript de los bloques embebidos.
- Parseo de XML Android.
- Prueba diferencial del culling: ningún punto que pasa el filtro de pantalla original queda fuera del AABB de mundo.
- Cuatro variantes visuales estables y sin nuevas claves de guardado.
- Integridad del ZIP y comparación de archivos nativos.
- No se afirma compilación APK ni medición de FPS real sin Android SDK/Gradle y dispositivo físico.
