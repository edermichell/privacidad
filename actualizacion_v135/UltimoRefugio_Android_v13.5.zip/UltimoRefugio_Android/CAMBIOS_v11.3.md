# Último Refugio Android — Cambios de la versión 11.3

## Compañeros operadores de torreta

- Se incorpora la orden **Operar torreta cercana (+25 % cadencia)** al diálogo de un compañero propio cuando existe una torreta libre a un máximo de **6.5 casillas**.
- El compañero se desplaza a una posición transitable junto a la torreta y permanece asignado a ese puesto.
- Mientras el compañero esté vivo, a no más de **4.8 casillas**, con más del **20 % de vida** y sin aturdimiento, la torreta reduce su enfriamiento un 25 % (de 1.25 s a un enfriamiento nominal de **1.0 s**). El ciclo de adquisición de objetivos de 0.28 s se mantiene, por lo que la cadencia real también depende de ese escaneo.
- La torreta conserva su daño, alcance, cargador y tipo de munición: cada disparo sigue causando 46 puntos de daño y consumiendo un cartucho 7.62.
- El compañero puede defender la posición usando su IA y arma habituales; cuando termina la amenaza vuelve al puesto.
- Se añade **Dejar torreta y seguirme** para retirar al compañero del puesto.
- Si la torreta se desmonta o desaparece, la orden se cancela automáticamente y el compañero vuelve a seguir al jugador.
- Solo se permite un operador por torreta. El indicador verde pixelado señala que la estructura está atendida.

## Compatibilidad de partidas y multijugador

- Se reutilizan los campos ya serializados `ord`, `gx` y `gy`; no se añaden claves ni campos obligatorios al guardado.
- `n.post` es un destino temporal y se reconstruye al cargar la partida.
- Las partidas antiguas y las torretas sin operador siguen funcionando sin migración.
- El anfitrión conserva la autoridad de simulación en cooperativo; el invitado no ejecuta daño local de torreta. La orden está disponible para los compañeros que controla el anfitrión; el invitado no puede asignar localmente un operador.
- `applicationId` conservado; `versionCode 105`; `versionName 11.3`.

## Validaciones ejecutadas

- Sintaxis JavaScript comprobada en los dos bloques `<script>` con `node --check`.
- Pruebas aisladas del módulo: asignación, exclusividad de operador, destino de guardia, bonificación del cooldown, suspensión por aturdimiento o distancia, reactivación al regresar, liberación manual y liberación automática cuando desaparece la torreta.
- Prueba de interfaz: el diálogo muestra la orden disponible y permite regresar al seguimiento; el evento se intercepta para evitar que lo procese también el manejador genérico.
- Cuatro archivos XML parseados; `applicationId`, `versionCode` y `versionName` verificados.
- Comparación de hashes: los archivos del proyecto que no debían cambiar se conservaron idénticos a la 11.2.
- ZIP reabierto y comprobado; contiene solamente el proyecto Android y su documentación.

## Pendiente

No se compiló APK/AAB ni se midieron FPS en un teléfono real: este entorno no dispone de Android SDK/Gradle ni de un dispositivo conectado. Se recomienda probar asignar un compañero, alejarse y volver, recibir una oleada, aturdir al operador, desmontar la torreta, guardar/cargar y probar una sesión anfitrión/invitado.
