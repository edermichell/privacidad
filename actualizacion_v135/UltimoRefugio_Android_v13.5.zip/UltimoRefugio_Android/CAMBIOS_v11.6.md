# Último Refugio Android 11.6

## Gráficos
- Los zombis corredores y Brutes levantan pequeños efectos de polvo pixelado al apoyar el pie. Se dibujan directamente en Canvas: no crean partículas ni objetos adicionales.
- El efecto se desactiva en calidad baja y no se aplica a zombis quietos, derribados o muertos.
- Se conserva el arte procedural, la resolución interna y el estilo pixel art existente.

## Rendimiento
- `drawZombie` reutiliza una única marca temporal por pasada de render, en lugar de llamar a `performance.now()` para cada zombi.
- La distancia de renderizado (`s91Far`) se calcula una sola vez por zombi y se reutiliza para las decisiones de sombra e inclinación.
- El presupuesto de rasterización de sprites humanos se adapta a la carga estimada, calidad y número de núcleos. En dispositivos más modestos o bajo carga se difiere más trabajo al proceso de tiempo libre ya existente, reduciendo los picos de trabajo dentro del fotograma.
- El presupuesto vuelve a crecer cuando hay margen, manteniendo el equilibrio entre respuesta visual y fluidez.

## Compatibilidad
- No se cambian sistemas de juego, daño, movimiento, IA, economía, redes ni estructuras de guardado.
- Se conservan `SAVEKEY`, `OPTKEY`, `buildSave`, `applySave`, `baseSave` y `baseLoad`.
- Se conserva el identificador de aplicación `com.impulso.ultimorefugio`.
- `versionName`: `11.6`; `versionCode`: `108`.

## Validaciones realizadas
- Ambos bloques JavaScript embebidos pasan `node --check`.
- Los cuatro XML Android pasan parseo.
- Prueba aislada del presupuesto adaptativo: el máximo baja con carga alta, baja calidad y pocos núcleos, y se recupera en condiciones holgadas.
- Prueba de polvo visual: solo se activa para corredores y Brutes en pasos seleccionados, sin alterar posiciones, salud, velocidades ni arrays de partículas.
- Comparación de archivos: únicamente cambian `index.html`, `app/build.gradle` y este registro.
- ZIP comprobado por integridad.

## Pendiente
No se compiló APK/AAB ni se midió FPS en un dispositivo físico. El rendimiento real debe medirse en teléfonos Android de distintas capacidades.
