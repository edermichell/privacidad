# Último Refugio 13.2.3 — corrección de límite 60 FPS

## Hallazgo
El informe 13.2.2 muestra un intervalo rAF de 33.3 ms (≈30 Hz) aunque el tope configurado era 60 FPS. El motor no convierte 60 en 30: el planificador solo limita callbacks, pero Android/WebView puede estar entregándolos a 30 Hz. Además, el limiter previo no distribuía bien los fotogramas en pantallas de 90 Hz.

## Cambios
1. Android ahora recibe la preferencia desde `AndroidMonet.setPreferredFps(30|60|0)` y pide `WindowManager.LayoutParams.preferredRefreshRate` a la ventana. Se utiliza una frecuencia admitida por el dispositivo, manteniendo la resolución física actual. Se vuelve a solicitar al regresar de segundo plano.
2. Se informa por F2 el objetivo configurado, rAF observado, refresco solicitado y refresco real que Android reporta después de la solicitud.
3. El HTML abierto directamente en Chrome muestra que no dispone de puente nativo; una página web no puede forzar el modo de refresco del sistema.
4. El limitador JS ahora usa plazos acumulativos. En una pantalla de 90 Hz puede alternar cadencias de 1 y 2 refrescos para aproximarse a 60 FPS, en lugar de quedarse en un ritmo de 45.
5. Al cambiar el objetivo de FPS se reinicia el plazo para evitar arrastrar el ritmo anterior.

## Sin cambios de contenido
No se añaden objetos, enemigos, efectos, recetas, misiones ni mecánicas. No se cambian daño, IA, movimiento, economía ni formato de guardados.

## Compatibilidad
- `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()` conservados.
- ID de aplicación conservado.
- `versionName`: `13.2.3`; `versionCode`: `128`.

## Límite del sistema
La preferencia Android es una solicitud, no una garantía. El sistema puede ignorarla por refresco máximo del panel, modo ahorro de batería, temperatura o restricciones del fabricante. Para confirmar que funciona hace falta instalar el APK en el teléfono y consultar F2.
