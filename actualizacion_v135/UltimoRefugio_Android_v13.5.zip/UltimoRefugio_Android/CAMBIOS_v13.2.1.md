# Último Refugio 13.2.1 — corrección crítica de renderizado

## Error corregido

La captura reportaba `render: ReferenceError: Q is not defined` repetidamente durante el dibujo de zombis.

La causa estaba en `drawZombie(z)`: la mejora de iluminación de borde de 13.2 usaba `Q.x` y `Q.y`, pero `Q` era una variable local de `render(dt)` y no existía en el ámbito de `drawZombie`.

## Solución

- `drawZombie` recibe ahora explícitamente `viewQ`.
- Los dos puntos de llamada del renderizador pasan la referencia local `Q`.
- La iluminación de borde solo calcula proximidad si existe una posición de vista válida; en caso contrario se omite de forma segura.
- Los wrappers anteriores de `drawZombie` reenvían `arguments`, así que conservan el parámetro añadido.
- Se declararon explícitamente los hooks heredados `bmTick`, `bmDrawScreen` y `bmAmb`, que se asignaban mediante `window` antes de su uso como nombres globales.
- Se eliminó un getter `STATE` duplicado e idéntico del objeto público `window.GAME`; la API observada no cambia.
- Se actualizó el pie del menú y la etiqueta del diagnóstico a 13.2.1.

## Auditoría adicional

- Se revisaron referencias libres a `Q` en los scripts: la única referencia sin declaración estaba en `drawZombie`; el resto eran parámetros locales, por ejemplo `evPush(push, Q)`, o propiedades como `filter.Q`.
- La comprobación estática de nombres no resueltos (TypeScript `TS2304`/`TS2552`) queda en cero tras declarar los hooks globales heredados.
- Las advertencias de TypeScript sobre tipos dinámicos del juego no son errores de sintaxis ni referencias globales no definidas.
- Se conservan `SAVEKEY`, `OPTKEY`, `baseSave()` y `baseLoad()`; no se modifica el formato de guardado.

## Validaciones realizadas

- Extracción de ambos bloques JavaScript y `node --check`.
- Auditoría de identificadores no resueltos.
- XML del proyecto Android parseado.
- Comparación de archivos del proyecto: solo cambia el HTML del juego, `app/build.gradle` y esta documentación.
- Integridad del ZIP comprobada.

## Pendiente

No se pudo completar una prueba de navegador en esta sesión porque Chromium bloquea la navegación a archivos y al servidor local con `ERR_BLOCKED_BY_ADMINISTRATOR`. Tampoco se compiló APK: el entorno no dispone de Android SDK/Gradle configurado. Por tanto, el arreglo queda verificado por análisis estático y sintaxis, pero requiere confirmación en tu navegador/dispositivo.
