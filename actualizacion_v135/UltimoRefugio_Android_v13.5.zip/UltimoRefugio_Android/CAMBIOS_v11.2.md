# Último Refugio Android — Cambios de la versión 11.2

## Nueva torreta automática

- Nueva receta **Torreta automática**: 6 tablones, 10 clavos, 4 piezas de chatarra y 1 tubo; requiere martillo y tarda 8 segundos.
- La receta produce una torreta en kit, que se coloca desde el inventario como las demás estructuras de base.
- Dispara automáticamente a zombis vivos dentro de **9.5 casillas** y solo cuando tiene línea de visión despejada.
- Cada disparo causa **46 puntos de daño**, consume 1 cartucho 7.62 y tiene un intervalo de 1.25 segundos.
- El cargador admite hasta **24 cartuchos 7.62**. Se recarga interactuando con la torreta; el modo sigilo mantiene la opción de desmontarla.
- La torreta emite ruido al disparar, por lo que puede atraer más zombis hacia la zona.
- El renderizado usa una silueta pixel art ligera y un indicador verde/rojo de munición.

## Compatibilidad y guardados

- La torreta se guarda en el arreglo `bs` de estructuras. Su registro extiende el formato de esa estructura con munición y nivel; los demás tipos mantienen exactamente sus cinco campos anteriores.
- Las torretas se reconstruyen con un máximo de 220 HP y entre 0 y 24 cartuchos.
- `SAVEKEY`, `OPTKEY`, `applicationId` y los formatos de inventario existentes no cambian.
- El anfitrión es autoridad para los disparos; los clientes invitados no ejecutan daño local de torreta.
- `versionCode 104`; `versionName 11.2`.

## Validaciones ejecutadas

- Sintaxis JavaScript de todos los bloques embebidos con `node --check`.
- Pruebas aisladas de fabricación/registro, guardado y carga de torretas, recarga exacta, consumo de munición, selección de objetivos, alcance, línea de visión, cooldown y autoridad de anfitrión.
- XML Android parseado; `applicationId` y metadatos de versión comprobados.
- Integridad del ZIP y hashes de archivos no modificados comprobados.

## Pendiente

No se compiló APK/AAB ni se midieron FPS en un dispositivo real: este entorno no dispone de Android SDK/Gradle ni de un teléfono conectado. Se recomienda probar en el juego la construcción, colocación, recarga con 7.62, disparos a través de espacios abiertos y bloqueo por paredes, guardado/carga y una sesión multijugador con anfitrión e invitado.
