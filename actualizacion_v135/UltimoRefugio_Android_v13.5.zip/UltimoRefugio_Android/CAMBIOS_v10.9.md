# Último Refugio Android 10.9

## Objetivo
Mejorar el combate contra los infectados especiales con una respuesta táctica clara frente al aullador, sin añadir presión continua al bucle de simulación ni alterar las partidas guardadas.

## Cambios incluidos

- **Interrumpir el aullido:** durante la preparación del aullido, un impacto fuerte (18 o más de daño), un golpe crítico, un ataque marcado como potente o el fuego cancela la llamada antes de que aparezca la horda.
- **Aturdimiento de respuesta:** al interrumpirlo, el aullador queda aturdido durante al menos 0.72 s. El tiempo se aplica después del daño para que el aturdimiento básico de los impactos no lo sobrescriba.
- **Golpes débiles conservan el riesgo:** los ataques de bajo daño no cancelan automáticamente el aullido, manteniendo la presión y la identidad del enemigo.
- **Feedback visual y sonoro:** un anillo de impacto y un signo de exclamación pixelado muestran brevemente que la preparación fue interrumpida. El dibujo adicional solo se ejecuta para el aullador visible y durante 520 ms.
- **Ayuda actualizada:** la descripción del aullador explica que puede interrumpirse con un golpe fuerte, crítico o fuego.
- **Compatibilidad:** no se modifican `SAVEKEY`, `OPTKEY`, estructuras de guardado, identificador de aplicación ni mensajes del protocolo multijugador. Los nuevos campos (`hwlBreakAt`, `hwlBreakNotified`) son transitorios y opcionales.
- **Versión Android:** `versionCode` 101 y `versionName` 10.9.

## Validaciones realizadas

- Sintaxis de los dos bloques JavaScript embebidos comprobada con Node.js.
- Pruebas unitarias aisladas: golpe débil no interrumpe; golpe fuerte, crítico y fuego sí interrumpen; zombis que no son aulladores y aulladores ya muertos no reciben el nuevo estado; el daño original se aplica una sola vez.
- Comprobación de flujo: la interrupción deja `howl = 0` y `stun >= 0.72`, por lo que la siguiente actualización no satisface ni la rama de finalización del aullido ni la condición de iniciar uno nuevo.
- Parseo de XML Android y revisión de `applicationId`, `versionCode` y `versionName`.
- Integridad del ZIP y comparación del conjunto de archivos.
- No se ejecutó compilación APK/AAB ni prueba física en un teléfono Android.

## Qué probar en dispositivo

1. Espera a que un aullador inicie su preparación y golpéalo con un arma ligera: el aullido debe continuar.
2. Repite con un arma contundente fuerte, un crítico y fuego: debe cancelar la llamada y quedar aturdido.
3. Confirma que la horda no aparece si interrumpes antes de terminar el aullido.
4. Deja que el aullido termine sin interrumpirlo y confirma que conserva su comportamiento habitual.
5. Repite en cooperativo: el anfitrión mantiene la autoridad del daño y del spawn; verifica visualmente ambos clientes.
6. Guarda y carga una partida con un aullador cerca; la partida debe seguir cargando, sin depender de los campos visuales temporales.
