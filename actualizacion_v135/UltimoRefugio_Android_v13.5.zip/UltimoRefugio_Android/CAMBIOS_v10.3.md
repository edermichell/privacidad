# Último Refugio Android 10.3

## Objetivo

Afinar el rendimiento con hordas grandes y hacer más justo el combate alrededor de obstáculos, sin cambiar el estilo pixel art ni los sistemas de guardado.

## Cambios incluidos

- **Percepción escalonada por distancia:** los zombis en persecución y los que están a 18 tiles o menos mantienen la frecuencia original de percepción (0.18–0.30 s). Los zombis que no están en persecución a distancia media consultan visión cada 0.34–0.44 s y los lejanos cada 0.58–0.70 s. Los ruidos siguen activando la investigación mediante `makeNoise`.
- **Rutas adaptativas para hordas:** la reconstrucción de los campos de flujo se mantiene en 0.4 s con poblaciones normales, pasa a 0.52 s cuando hay más de 100 zombis y a 0.68 s por encima de 180. El cálculo continúa usando los buffers reutilizables existentes.
- **Combate con línea de visión:** los ataques de zombis contra jugador/anfitrión/invitado, los mordiscos contra NPC y los ataques cuerpo a cuerpo de compañeros ahora requieren línea de visión despejada. Los compañeros continúan intentando acercarse al objetivo si un obstáculo les bloquea el ataque.
- **Versión Android:** `versionCode` 95 y `versionName` 10.3. Se conserva el `applicationId`.

## Compatibilidad y guardados

No se modificaron `SAVEKEY`, `OPTKEY`, `localStorage`, los formatos de serialización, tablas de objetos, inventario, identificadores de productos, estado de multijugador ni contenido de las partidas. No se añadieron migraciones.

## Validaciones realizadas

- Comprobación de sintaxis JavaScript con Node.js (`node --check`) sobre todos los bloques JavaScript embebidos.
- Comprobación de estructura e integridad del ZIP.
- Verificación de `applicationId`, `versionCode`, `versionName`, `SAVEKEY` y `OPTKEY`.
- Comparación de archivos: fuera del HTML principal, versión Gradle y documentación, los archivos permanecen iguales a 10.2.
- No se ejecutó compilación Android ni prueba física en dispositivos; el APK/AAB debe compilarse y probarse antes de publicar.

## Pruebas recomendadas

1. Acercarse caminando, corriendo y haciendo ruido a zombis a distintas distancias; verificar que la percepción cercana se conserva y los ruidos siguen atrayéndolos.
2. Probar hordas con más de 100 y 180 zombis; comprobar persecución, rodeo de obstáculos y respuesta al jugador.
3. Dejar que un zombi alcance al jugador junto a paredes, puertas, ventanas y vallas; no debe morder a través de obstáculos opacos.
4. Reclutar un superviviente y observar su combate cuerpo a cuerpo con zombis separados por paredes y en espacios abiertos.
5. Probar zombis mordiendo NPC en exteriores, interiores y junto a puertas.
6. Verificar guardado/carga, vehículos, clima, construcción y multijugador host/invitado.
