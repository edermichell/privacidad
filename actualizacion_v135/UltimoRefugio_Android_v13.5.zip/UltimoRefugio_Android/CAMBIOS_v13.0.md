# Último Refugio 13.0 — cambios técnicos

## Objetivo
Reducir la variedad de sprites de animación que se solicitan para NPC tranquilos y caminantes comunes a media/larga distancia. Mantener animación completa para el jugador, compañeros, hostiles, personajes en interacción/combate y zombis especiales.

## Implementación
- `npcSpec()` cuantiza únicamente el frame de dibujo para civiles móviles no importantes: a 6–12 casillas utiliza 8 fases; a más de 12 casillas utiliza 4 fases.
- Compañeros, hostiles, NPC que hablan, atacan, están aturdidos, huyen, persiguen o pelean restauran las 16 fases completas, incluso si un LOD previo las había cuantizado.
- En calidad baja se conserva el LOD más agresivo heredado de la 11.7 para NPC lejanos (2 fases); no se aumenta la carga de esa configuración.
- `zSpec()` aplica LOD solamente a caminantes básicos en estados wander/chase: a 8–14 casillas utiliza 8 fases y a más de 14 casillas utiliza 4 fases.
- Brutes, runners, crawlers, screamers y zombis quemándose/aturdidos/en embestida conservan las 16 fases.
- El LOD cambia solo `sp.frame`, que es una especificación visual temporal. No modifica `anim`, velocidad, posición, percepción, combate ni daño.
- No añade propiedades a NPC/zombis y no modifica `SAVEKEY`, `OPTKEY`, `baseSave()` ni `baseLoad()`.
- F2 muestra contadores de uso por nivel de detalle para NPC y caminantes.

## Pruebas ejecutadas
- Sintaxis de los dos bloques JavaScript: `node --check`.
- Prueba del wrapper LOD combinada con la lógica previa 11.7: distancias, calidad baja, estados protegidos y clases de zombi.
- Prueba de cuantización de los 16 frames: salida de 8 fases usa frames pares; salida de 4 fases usa 0/4/8/12.
- Comprobaciones de exclusión: estados de combate/interacción y tipos especiales quedan en 16 fases, salvo el LOD bajo heredado en NPC lejanos cuando la calidad baja está activa.
- Claves y funciones de guardado comparadas con 12.9: sin cambios.
- XML Android parseados correctamente; `versionCode 123`, `versionName 13.0`.
- HTML web y `app/src/main/assets/index.html` idénticos byte por byte.
- ZIP verificado con `unzip -t`.

## Limitaciones
No se afirma una mejora porcentual de FPS sin medir en el dispositivo objetivo. El beneficio esperado es reducir combinaciones de sprites y misses de caché en campamentos poblados. Se debe comprobar con F2 en el mismo campamento. La navegación automatizada de Chromium está bloqueada en este entorno, así que el arranque del HTML debe confirmarse en el navegador del usuario. No se compiló APK/AAB por falta de Android SDK/Gradle.
