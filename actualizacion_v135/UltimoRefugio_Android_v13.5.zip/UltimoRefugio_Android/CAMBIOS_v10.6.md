# Último Refugio Android 10.6

## Objetivo
Añadir una orden de patrulla para los compañeros reclutados, ampliando el sistema de órdenes existente sin reemplazar el seguimiento, la guardia ni la búsqueda de suministros.

## Cambios incluidos

- **Nueva orden «Patrullar esta zona»:** el compañero recorre seis puntos posibles en un perímetro de aproximadamente 4 casillas alrededor del lugar donde se le da la orden.
- **Combate durante la patrulla:** el compañero conserva su detección de amenazas y su comportamiento de combate; al desaparecer el peligro reanuda el recorrido.
- **Órdenes compatibles:** desde el diálogo se puede volver a ordenar que siga al jugador o cambiarlo a guardia fija. Las órdenes de búsqueda de suministros existentes permanecen disponibles. Si el entorno no ofrece casillas transitables, el sistema espera antes de reintentar en vez de buscar en cada fotograma.
- **Persistencia compatible:** la patrulla reutiliza `ord`, `gx` y `gy`, campos que ya estaban incorporados al conjunto de guardado de compañeros. El destino momentáneo de la ronda no se serializa; se reconstruye al cargar.
- **Multijugador:** las órdenes de compañeros siguen limitadas al propietario y no se habilita esta función en sesiones multijugador, igual que las órdenes locales existentes.
- **Versión Android:** `versionCode` 98 y `versionName` 10.6; `applicationId` sin cambios.

## Validaciones realizadas

- Sintaxis de todos los bloques JavaScript embebidos comprobada con Node.js.
- Prueba aislada del selector de puntos de patrulla: destinos válidos, distancia acotada al puesto y fallback cuando no se encuentra suelo libre.
- Prueba de la lógica de actualización: el recorrido cambia al alcanzar un punto o vencer el intervalo, y se pausa mientras hay una amenaza activa.
- Comprobación estática de que `NSAVE` ya incluye `ord`, `gx` y `gy` y que no se alteran `SAVEKEY`, `OPTKEY` ni la serialización de partida.
- Parseo de los XML Android, revisión de `applicationId`, `versionCode`, `versionName` e integridad del ZIP.
- No se ejecutó compilación APK/AAB ni prueba física en un teléfono Android.

## Pruebas recomendadas en dispositivo

1. Reclutar un compañero en una zona abierta y ordenarle patrullar.
2. Comprobar que recorre el perímetro y no se aleja más de unas pocas casillas del punto asignado.
3. Atraer zombis hacia la zona, verificar que combate y luego reanuda la ronda.
4. Cambiar entre patrulla, guardia y seguimiento.
5. Guardar/cargar durante una patrulla y confirmar que retoma una ruta local.
6. Confirmar que las órdenes de búsqueda de suministros y el multijugador siguen funcionando.
