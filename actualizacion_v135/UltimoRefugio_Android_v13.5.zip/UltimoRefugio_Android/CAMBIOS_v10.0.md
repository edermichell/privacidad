# Último Refugio Android 10.0

## Objetivo

Evolución conservadora del proyecto 9.9: conservar el pixel art, los sistemas de juego, el multijugador, la economía, los anuncios/compras y los guardados existentes, priorizando el equilibrio entre calidad visual y rendimiento.

## Cambios incluidos

- **Calidad automática con recuperación:** ahora mide el tiempo real de trabajo del juego, tiene umbrales distintos para el límite de 30 FPS y para 60/libre, y puede recuperar los detalles cuando el dispositivo vuelve a tener margen. La histéresis reduce los cambios repetidos de calidad.
- **Menos memoria de caché gráfica:** se ajustó el límite mínimo de bloques de terreno según la resolución interna. El modo Ultra deja de forzar 48 bloques de alta resolución, que podían rondar 96 MiB solo para esta caché.
- **Menos basura por fotograma:** se reutilizan el mapa de buckets de entidades, sus arreglos y la lista de luces en el renderizado, evitando reconstruir esas estructuras en cada cuadro.
- **Menos trabajo inútil en la simulación:** se eliminó una lista temporal de zombis cercanos que se llenaba pero nunca se utilizaba. La actualización y las reglas de los zombis permanecen iguales.
- **Versión Android:** `versionCode` 92 y `versionName` 10.0. Se mantiene el mismo `applicationId`.

## Compatibilidad y guardados

No se cambiaron `SAVEKEY`, los formatos de serialización, los nombres de las claves de `localStorage`, los identificadores de productos, las tablas de objetos ni las reglas de carga de partidas. No se añadieron migraciones destructivas ni se borraron datos.

## Validación realizada

- Se comprobó la sintaxis JavaScript del archivo principal con Node.js (`node --check`).
- Se verificó que el ZIP incluye el proyecto Android completo y los recursos originales.
- No se certifica compilación Gradle ni funcionamiento en dispositivos físicos: este entorno no ejecutó una compilación Android ni pruebas de juego en un teléfono. Esas comprobaciones deben realizarse antes de publicar.

## Recomendación antes de publicar

1. Instalar el APK en un dispositivo de gama baja, uno medio y uno alto.
2. Probar carga, guardado, cierre forzado, reanudación y actualización desde 9.9.
3. Probar hordas grandes, lluvia, noche, interiores, conducción y multijugador.
4. Verificar anuncios y compras con los secretos y cuentas de prueba de Play Console.
