# Último Refugio 12.0

## Objetivo
Actualización técnica centrada en instrumentación del motor y calidad automática basada en cadencia real.

## Cambios
- El diagnóstico ahora separa intervalo real de `requestAnimationFrame` del tiempo de trabajo JavaScript.
- Desglose de simulación, renderizado, HUD/red/audio, guardado y trabajo diferido.
- P95 y máximo separados para intervalo real y trabajo JS, con detección de muestras >50 ms y exclusión de reanudaciones >250 ms.
- Contadores de sprites solicitados, hits, misses, expulsiones, sprites pendientes y presupuesto de generación.
- Entidades activas y visibles aproximadas por cámara, además del total de partículas y la caché de sprites frente a su límite calculado.
- Los buffers estadísticos son circulares y el muestreo detallado solo se activa con el panel abierto.
- La calidad automática ahora combina el tiempo de trabajo JS con el intervalo real de fotogramas. Esto evita que una carga con FPS bajos se considere fluida solo porque el JS tarde menos de 20 ms.
- El trabajo diferido se omite en fotogramas lentos (intervalo >=50 ms o trabajo JS >=10.5 ms) para no agravar tirones.
- Se mantiene la proyección y culling compartidos de partículas/luciérnagas de 11.9.

## Compatibilidad
- No cambia `SAVEKEY`, `OPTKEY`, `buildSave`, `baseSave` ni `baseLoad`.
- Se mantienen los formatos de partidas y los sistemas de juego.
- `versionCode 112`, `versionName 12.0`.

## Validaciones
- JavaScript: sintaxis validada.
- Pruebas del ring de muestras, percentiles, picos y exclusión de reanudaciones.
- Comprobación de claves y funciones de guardado contra 11.9.
- XML Android y ZIP comprobados.
- No se dispone de Android SDK/Gradle en este entorno; no se afirma compilación APK ni FPS medidos en un dispositivo.

## Prueba en navegador
- Chromium headless: carga completa del HTML, creación de partida de prueba, panel F2 abre/cierra con Escape y sin errores JavaScript.
- Prueba sintética del diagnóstico: 180 muestras de ventana, un pico de 194 ms de trabajo JS, un intervalo de 80 ms y una reanudación de 300 ms; se detectaron los contadores correctamente y la reanudación quedó excluida del percentil.
