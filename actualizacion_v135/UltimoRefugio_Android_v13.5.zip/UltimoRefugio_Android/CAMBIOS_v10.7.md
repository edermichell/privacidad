# Último Refugio Android 10.7

## Objetivo
Dar al zombi bruto un ataque de área legible y evitable, aumentando la variedad del combate sin introducir nuevos sprites pesados ni cambiar el guardado.

## Cambios incluidos

- **Golpe de suelo del bruto:** cuando persigue al objetivo a corta-media distancia y tiene línea de visión, se prepara durante 0.82 segundos antes de golpear.
- **Aviso visual pixel art:** un anillo rojo en el suelo marca el alcance aproximado del impacto; se dibuja solo durante la preparación.
- **Ventana de evasión:** el impacto falla si el jugador se aleja, entra en un vehículo o rompe la línea de visión antes de que termine la carga.
- **Interrupción:** aturdir, derribar o prender fuego al bruto cancela la preparación.
- **Impacto equilibrado:** si alcanza al jugador, reutiliza el daño de mordida del bruto ya existente y añade un breve desequilibrio/empujón solo cuando el golpe realmente resta salud. Tiene un enfriamiento de 10–12.5 segundos.
- **Cooperativo:** se replica el estado de aviso con un bit opcional de red; los clientes antiguos ignoran ese bit y los invitados nuevos lo muestran sin simular el daño localmente.
- **Persistencia:** `brace`, `braceCd` y `braceVisual` son temporales. No se añaden campos a `SAVEKEY`, `OPTKEY`, `NSAVE` ni a los arreglos de zombis guardados.
- **Versión Android:** `versionCode` 99 y `versionName` 10.7; `applicationId` sin cambios.

## Validaciones realizadas

- Sintaxis de los bloques JavaScript embebidos comprobada con Node.js.
- Pruebas aisladas del ciclo de preparación: aviso, impacto, fallo por distancia/vehículo/obstáculo e interrupción por aturdimiento.
- Comprobación estática del bit de aviso de red y de la compatibilidad con paquetes antiguos (bit opcional no reconocido).
- Parseo de los XML Android, revisión de `applicationId`, `versionCode`, `versionName` e integridad del ZIP.
- Verificación de que las claves y campos de guardado originales permanecen iguales.
- No se ejecutó compilación APK/AAB ni prueba física en un teléfono Android.

## Pruebas recomendadas en dispositivo

1. Enfrentarse a un bruto en terreno abierto y comprobar que el anillo avisa antes del golpe.
2. Alejarse del anillo durante la preparación y confirmar que el golpe falla.
3. Probarlo detrás de una pared, dentro de un vehículo y con una ventana/puerta entre ambos.
4. Interrumpirlo con un arma o fuego y comprobar que cancela el ataque.
5. Comprobar que no repite el golpe continuamente y que otros tipos de zombi conservan su comportamiento.
6. Probar la advertencia visual en una sesión cooperativa con ambos clientes actualizados.
7. Guardar/cargar mientras hay brutos en el mundo y comprobar que la partida abre con normalidad.
