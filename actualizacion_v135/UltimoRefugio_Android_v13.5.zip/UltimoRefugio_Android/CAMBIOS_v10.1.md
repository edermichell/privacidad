# Último Refugio Android 10.1

## Objetivo

Segunda actualización conservadora sobre 10.0: mantener pixel art, jugabilidad, contenido, multijugador y guardados, reduciendo la presión de memoria del renderizado.

## Cambios incluidos

- **Pool de entradas de dibujo:** las entradas usadas para ordenar zombis, NPC, jugadores, vehículos, fauna, trampas, fauna doméstica, cultivos, objetos, fuegos, alarmas, proyectiles, generadores y elementos de la base ahora se reutilizan entre fotogramas.
- **Buckets existentes conservados:** se mantiene la misma agrupación por diagonal, profundidad y orden de dibujo; el cambio afecta a la asignación de objetos temporales, no a la lógica de renderizado.
- **Versión Android:** `versionCode` 93 y `versionName` 10.1. Se conserva el `applicationId`.

## Compatibilidad y guardados

No se modificaron `SAVEKEY`, `localStorage`, los formatos de serialización, las tablas de objetos, las reglas de carga, los identificadores de productos ni las mecánicas. No se añadieron migraciones de guardado.

## Validaciones realizadas

- Se comprobó la sintaxis JavaScript con Node.js (`node --check`).
- Se comprobó que no quedan llamadas al antiguo `push(key, objetoLiteral)` del renderizado.
- Se verificó la integridad del ZIP y la presencia de los archivos Android y recursos originales.
- No se ejecutó compilación Android ni prueba física en dispositivos; el APK/AAB debe compilarse y probarse antes de publicar.

## Pruebas recomendadas

1. Comparar FPS y fluidez con hordas grandes y fauna activa.
2. Probar escenas con NPC, animales, trampas, cultivos y defensa de base para comprobar el orden visual.
3. Probar guardado, carga, cierre forzado y actualización desde 10.0.
4. Probar conducción, clima, noche y multijugador.
