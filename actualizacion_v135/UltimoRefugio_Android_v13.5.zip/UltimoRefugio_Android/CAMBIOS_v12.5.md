# Último Refugio 12.5 — Cambios

## Objetivos
Reducir asignaciones temporales en el render y corregir la frecuencia de mantenimiento de fauna, conservando las mecánicas y el formato de partidas de 12.4.1.

## Cambios

### Renderizado
- Se añadió `w2sRender(x, y)`, que reutiliza una pareja de coordenadas temporal para conversiones usadas de forma inmediata en destructuring.
- Se migraron 89 puntos de dibujo que consumían el resultado en el mismo instante. Los usos de `w2s()` que conservan o indexan el arreglo siguen usando la función original para no exponer una referencia reutilizada.
- Se añadió un contador de proyecciones reutilizadas al panel F2.
- Se movió el cálculo de máscara de vecinos de cercas fuera del recorrido por baldosa; conserva el mismo orden de bits y la misma selección de sprite.

### Fauna
- El mantenimiento de animales se ejecuta una sola vez por actualización de mundo (`evUpdate`).
- En 12.4 el mismo temporizador se descontaba desde cuatro envoltorios de actualización de especies (fauna, gatos, ratas y perro), adelantando aproximadamente cuatro veces el escaneo periódico previsto.
- Ahora el chequeo periódico recorre la fauna una vez por tick y mantiene el intervalo de 0.35 s de tiempo simulado.
- El informe de fauna añade ejecuciones y revisiones del mantenimiento.

### Compatibilidad y arranque
- Se conserva la inicialización temprana de `TIME` incorporada en 12.4.1 para evitar `ReferenceError` al construir la vista previa del menú.
- Se conservan `SAVEKEY = ultimo_refugio_v3`, `OPTKEY = ultimo_refugio_opt`, `baseSave()` y `baseLoad()`.
- No cambian el manifiesto, el identificador de aplicación ni los recursos nativos de Android.

## Validación realizada
- Sintaxis de los dos bloques JavaScript inline validada con `node --check`.
- XML Android parseados correctamente.
- Comparación contra 12.4.1: solo cambian `app/build.gradle` y `app/src/main/assets/index.html` dentro del proyecto.
- 100,000 conversiones de coordenadas comparadas con la función anterior; valores coincidentes y destructuring estable.
- 100,000 máscaras de cercas comparadas con el cálculo inline anterior; resultados idénticos.
- Simulación del mantenimiento confirma que ahora el temporizador avanza una vez por actualización de mundo.
- El HTML independiente es byte por byte idéntico al `index.html` incluido en Android.

## Pendiente
No se completó una prueba real en Chromium/WebView: la política del entorno de validación bloqueó la navegación a archivos y servidores locales (`ERR_BLOCKED_BY_ADMINISTRATOR`). Tampoco se compiló APK/AAB; no hay Android SDK/Gradle disponible en este entorno. Probar en navegador y dispositivo antes de publicar.
