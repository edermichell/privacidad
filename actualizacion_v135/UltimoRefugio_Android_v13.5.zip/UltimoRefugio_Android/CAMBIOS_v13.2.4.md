# Último Refugio 13.2.4 — revisión de 13.2.3 y correcciones

## Error crítico encontrado (introducido en 13.2.2, presente en 13.2.3)
`npcThreat` usaba `mayBest` y `mayVisible`, que no estaban definidas. Cada vez que un NPC tenía un zombi dentro de 10 casillas se lanzaba `ReferenceError` y `updateGame` se interrumpía a mitad de fotograma; el protector v80 lo ocultaba (guarda `ur_err80` y no muestra aviso hasta 40 fallos seguidos). En una prueba con Chromium: 850 excepciones en 15 s con una horda. La parte de la simulación posterior al fallo (IA de zombis/NPC) no se ejecutaba en esos fotogramas.
- Corrección: `mayBest = d < bd || (d === bd && zi < bestOrder)` y `mayVisible = d < vd || (d === vd && zi < visOrder)`, con el mismo orden de preferencia y filtro de línea de visión.
- Verificación: ESLint `no-undef` sobre los dos bloques de script; 13.2.3 → 2 errores (`mayBest`, `mayVisible`), 13.2.4 → 0. Prueba con horda en Chromium: 0 excepciones.
- La nota de 13.2.1 y la de 13.2.2 daban por buena la auditoría de nombres; esta prueba muestra que no se repitió tras reescribir `npcThreat`.
- Efecto esperable: más trabajo real por fotograma (la simulación ya no se corta), así que el FPS puede bajar un poco frente a 13.2.3 en escenas con zombis. Es el coste correcto de que el juego funcione completo.

## Otros hallazgos de la revisión de 13.2.3
1. **Versiones incoherentes**: el pie del menú seguía en 13.2.2 y el encabezado del diagnóstico (8 puntos del código) también, aunque el informe decía 13.2.3.
2. **Consejo de diagnóstico engañoso**: al ver rAF ≈ 30 Hz con tope 60, siempre culpaba al sistema Android. Con vsync, si el trabajo JS supera 16.7 ms el fotograma salta al siguiente refresco y rAF cae a 33 ms sin que Android haga nada. La hipótesis de 13.2.3 no estaba comprobada.
3. **Tolerancia fija de 0.75 ms** en el limitador: con jitter de vsync mayor, en 60 Hz se descartaban fotogramas válidos. Simulación (20 semillas): jitter ±1.5 ms → 53.6 FPS antes, 60.0 ahora.
4. **Petición de refresco nativa débil**: solo `preferredRefreshRate`; en Android 11+ el id de modo es la solicitud más fiable.

## Cambios
- Lienzos pequeños (≤ 40 000 px: sprites, texturas de decals) creados con `willReadFrequently`, como ya hacía `hiCv`. Antes, `humanShade`, `epx` y `dcSprite` leían píxeles de canvas sin esa opción (Chromium avisaba y, en móvil con GPU, cada lectura puede ser lenta). Mapa y chunks del terreno quedan en GPU. En Chromium sin GPU no hay diferencia medible de FPS; el efecto en móvil no está medido.
- Versión unificada a 13.2.4 (menú, diagnóstico, informe, `versionName`, `versionCode 129`).
- Limitador: tolerancia adaptativa (25 % del intervalo vsync observado, entre 0.75 y 4 ms); se reinicia al cambiar el tope.
- Diagnóstico: distingue "coste del juego" (trabajo JS medio > 13.5 ms) de "límite del sistema" y muestra el trabajo medio.
- Android: además de `preferredRefreshRate`, se solicita `preferredDisplayModeId` del modo elegido (mismo tamaño de pantalla); 0 en modo automático.

## Sin cambios de contenido
No se tocan jugabilidad, IA, economía, `SAVEKEY`, `OPTKEY`, `baseSave()` ni `baseLoad()`.

## Validaciones
- Ambos bloques JavaScript pasan `node --check`.
- ESLint `no-undef`: 0 errores.
- Chromium headless (Playwright): arranque sin errores, partida nueva, intro omitida, F2 y horda sin excepciones; tope 60 → 60 FPS y tope 30 → 30 FPS en un 60 Hz limpio.
- Simulación del limitador en 60/90/120 Hz con jitter (el navegador de prueba no tiene jitter, así que esa mejora solo se comprobó en simulación).
- Revisión de imports y limpieza de callbacks en `onDestroy` de `MainActivity.java`.

## Pendiente (no verificado)
No se compiló el APK (sin Android SDK/Gradle) ni se probó en un teléfono; las pruebas de navegador usan renderizado por software, así que sus FPS no equivalen a los del móvil. Si en F2 el trabajo JS medio supera ~14 ms, el límite de 30 FPS es de rendimiento del juego y habrá que optimizar o bajar la calidad.
