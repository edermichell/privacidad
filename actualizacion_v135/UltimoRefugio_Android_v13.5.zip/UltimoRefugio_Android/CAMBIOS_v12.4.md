# Último Refugio 12.4

**Versión Android:** `12.4`  
**versionCode:** `116`  
**Base:** 12.3

## Objetivo de la actualización

Atender dos observaciones de juego real: animales que quedaban atascados contra paredes/armarios y el coste alto de la fase `world` en escenas con campamentos poblados. Se amplía también el diagnóstico para separar mejor ese coste.

## Cambios

### Navegación y colisiones de fauna

- Se reemplazó el muestreo de nueve puntos por colisión círculo–baldosa sólida mediante la distancia al rectángulo de cada tile. Esto cubre mejor las esquinas de muebles, armarios y paredes.
- Las puertas abiertas siguen siendo transitables; las cerradas, ventanas, agua, muebles y límites del mapa continúan bloqueando.
- Se conserva el barrido de movimiento en pasos de hasta `0.075` casillas, desvíos laterales, deslizamiento por eje y recuperación local de animales que ya aparecían dentro de un obstáculo.
- Las comprobaciones de vehículos usan directamente sus semiejes, evitando crear el arreglo auxiliar `carExt()` en cada prueba.
- Las rutas usan cuatro objetos scratch reutilizables en vez de crear tuplas/arreglos para cada intento de movimiento.
- El panel muestra recuentos de pruebas de colisión y rutas.

### Renderizado del mundo y diagnóstico

- La fase `world` ahora se desglosa en `tileWork`, `bucketSort`, `entityDraw` y `roofDraw`.
- Cada subfase se resume en una ventana de 180 fotogramas con media, P95 y máximo.
- Se muestran los tipos de entidad dibujados en el último cuadro: zombis, NPC, vehículos y otros.
- Se conserva el desglose por fases ya existente. El nuevo desglose permite distinguir si el mayor coste proviene de dibujar entidades, ordenar buckets, dibujar techos o del resto del recorrido de tiles.

### Caché y sprites de NPC

- Los sprites registran su último uso en cada hit y se promueven en el orden LRU con una cadencia máxima de `0.24 s` (antes `0.9 s`).
- Los civiles de fondo lejanos (`survivor`, `refugee`, `drifter`) pueden compartir una de 24 paletas deterministas. Solo afecta a la representación devuelta al dibujador: no modifica el NPC guardado.
- Se excluyen NPC cercanos, hostiles, comerciantes, médicos, compañeros, personajes en diálogo, siguiendo al jugador o involucrados en combate.
- No se incrementó el presupuesto de memoria gráfica de 12.3.

## Compatibilidad

- Sin cambios en `SAVEKEY` (`ultimo_refugio_v3`) ni `OPTKEY` (`ultimo_refugio_opt`).
- `baseSave()` y `baseLoad()` permanecen idénticas a 12.3.
- Se mantienen el `applicationId`, el proyecto Android, el multijugador, las estructuras, las recetas y los sistemas de juego existentes.
- No se agregan campos persistentes; los contadores de fauna y las paletas son temporales/deterministas.

## Validaciones realizadas

- Ambos bloques JavaScript embebidos pasaron `node --check`.
- Ocho pruebas aisladas de fauna: pared, esquina de mueble, puerta abierta/cerrada, recuperación desde obstáculo, pasillo de una baldosa, esquina diagonal, colisión con vehículo y precisión del círculo en esquinas.
- Seis pruebas de paletas: determinismo, no mutación del NPC original, apariencia cercana sin cambios, exclusión de hostiles y compañeros, y 24 combinaciones diferenciadas.
- Prueba de estadísticas del render con 180 muestras: media, P95, máximo y reinicio de ventana.
- Se compararon `SAVEKEY`, `baseSave()` y `baseLoad()` con 12.3: sin cambios.
- Se comprobaron los XML Android y la integridad del ZIP.

## Pendiente

No se compiló APK/AAB porque el entorno de trabajo no dispone de Android SDK/Gradle configurado. La automatización de Chromium tampoco pudo terminar una prueba de apertura en este entorno; por eso se recomienda validar el HTML en Chrome/Edge y probar animales en una partida real. No se afirma una mejora de FPS hasta recibir una medición comparable del dispositivo.
