# Último Refugio 12.4.1 — corrección de arranque (hotfix)

## Error crítico corregido

El HTML 12.4 se detenía durante la evaluación del script principal con:

`ReferenceError: Cannot access 'TIME' before initialization`

La cadena de llamadas era `renderMenuOpts()` → `drawPreview()` → `humanSprite()`. `humanSprite()` consultaba `TIME` para actualizar la LRU de `HC2`, pero `TIME` estaba declarado más adelante con `let`, por lo que seguía en su zona temporal muerta (TDZ). Al abortarse el script, `boot()` nunca se ejecutaba y el canvas quedaba negro cuando desaparecía la pantalla de carga.

## Correcciones

1. `TIME` se inicializa antes de la función `humanSprite()` y se elimina su declaración tardía duplicada.
2. La pantalla de carga ya no se elimina ciegamente tras 25 segundos: si el arranque falla, muestra un mensaje de error en vez de dejar una pantalla negra.
3. Se marca `window.__UR_BOOT_OK` solo después de que `boot()` termina correctamente.

## Validación

- `node --check` de ambos bloques JavaScript.
- Ejecución en Chromium con HTML embebido: el menú inicializa, `window.GAME` existe, `STATE` queda en `menu`, desaparece la pantalla de carga y no se producen errores JavaScript no capturados.
- Las pruebas con `about:blank` registran advertencias de almacenamiento local denegado por el entorno de prueba; no impiden el arranque y no equivalen a un fallo al abrir el archivo local en Chrome/Edge.
- El HTML independiente coincide byte por byte con `app/src/main/assets/index.html`.
- Se conserva el código de juego, las claves de guardado y el identificador de aplicación. `versionCode` 117, `versionName` 12.4.1.

## Límite

No se compiló APK/AAB ni se hizo una prueba en un dispositivo Android físico.
