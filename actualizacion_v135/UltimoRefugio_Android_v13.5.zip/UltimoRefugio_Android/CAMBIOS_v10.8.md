# Último Refugio Android 10.8

## Objetivo
Reducir la presión de memoria del recolector de basura durante hordas grandes, manteniendo sin cambios la separación física ya existente entre zombis.

## Cambios incluidos

- **Buffers reutilizables para separar hordas:** el hash espacial de la separación conserva los mismos filtros (zombis vivos, no derribados ni trepando, radio de 34 casillas, sin invitados en multijugador).
- **Buckets reciclados:** se reutilizan las listas de cada celda mediante un pool de tamaño limitado al máximo simultáneo de celdas activas; el mapa no acumula coordenadas de todo el mundo.
- **Menos estructuras temporales:** la lista de trabajo y las entradas de empuje se reutilizan. Los vectores por zombi están en `WeakMap` y no se incluyen en los guardados.
- **Física sin cambios:** conserva el mismo orden de recorrido, umbral de separación, fórmula de empuje, `moveEnt`, límites y reglas de colisión.
- **Compatibilidad:** no cambia el esquema de guardado, `SAVEKEY`, `OPTKEY`, `NSAVE`, protocolo multijugador ni `applicationId`.
- **Versión Android:** `versionCode` 100 y `versionName` 10.8.

## Validaciones realizadas

- Prueba diferencial de la separación original frente a la versión con buffers reutilizados, con escenarios aleatorios, zombis solapados, fuera del radio, derribados, trepando, con retroceso y jefes; se comparan posiciones, bump y contador de empujes.
- Prueba de varios ticks con desplazamiento del jugador para verificar el reciclaje de buckets y que el mapa solo conserve las celdas activas del tick.
- Sintaxis de JavaScript embebido comprobada con Node.js.
- Parseo de XML Android, revisión de `applicationId`, `versionCode` y `versionName`.
- Integridad del ZIP y comparación de los archivos no modificados.
- No se ejecutó compilación APK/AAB ni prueba física en un teléfono Android.

## Qué probar en dispositivo

1. Generar hordas grandes y observar que los zombis ya no se apilen exactamente en un mismo punto.
2. Probar la separación cerca de paredes, puertas, vallas, autos y al lado de interiores.
3. Cambiar de zona rápidamente y comprobar que no se degrada la memoria al acumular buckets antiguos.
4. Probar cooperativo y verificar que el invitado sigue recibiendo las posiciones autoritativas del anfitrión.
5. Guardar/cargar con zombis activos y confirmar que la partida sigue abriendo normalmente.
