# Último Refugio Android 10.5

## Objetivo

Cerrar una regresión introducida por un parche tardío de línea de visión: la versión 10.4 construía un índice espacial de zombis para la IA de NPC, pero una redefinición posterior de `npcThreat` volvía a recorrer `Z` completa. La 10.5 conserva la lógica de visibilidad y vuelve a usar el índice espacial.

## Cambios incluidos

- **Búsqueda de amenazas indexada de extremo a extremo:** la última redefinición de `npcThreat` consulta ahora `npcGridEachNear` en lugar de recorrer todos los zombis. El índice se construye una vez al comienzo de `updNpcs()`.
- **Línea de visión y desempate conservados:** sigue priorizándose el enemigo visible más cercano; los NPC armados/hostiles no seleccionan enemigos ocultos. En empates de distancia se conserva el orden original de `Z` mediante un `WeakMap` temporal, sin añadir propiedades serializables a los zombis.
- **Filtros originales conservados:** estados `dead`/`down`, límites de ±10 tiles, cálculo de distancia, orden de desempate y `thrD` mantienen la misma lógica.
- **Versión Android:** `versionCode` 97 y `versionName` 10.5. Se conserva `applicationId`.

## Compatibilidad y guardados

No se modifican `SAVEKEY`, `OPTKEY`, `localStorage`, serialización de partidas, inventario, construcción, vehículos ni protocolo multijugador. El índice espacial sigue siendo temporal y no se incluye en el guardado. No se requiere migración.

## Validaciones realizadas

- Comprobación sintáctica de todos los bloques JavaScript embebidos con Node.js.
- Prueba diferencial determinista de la selección de objetivo: la búsqueda indexada se comparó con el recorrido completo de referencia en múltiples disposiciones, incluyendo zombis muertos/derribados, amenazas ocultas y visibles, y NPC armados/desarmados.
- Verificación de que la función final `npcThreat` usa `npcGridEachNear` y no contiene un recorrido completo `for (const z of Z)`.
- Parseo de los XML de Android y verificación de `applicationId`, `versionCode`, `versionName`, `SAVEKEY` y `OPTKEY`.
- Verificación de integridad del ZIP y comparación de archivos del proyecto.
- No se ejecutó compilación Android ni prueba física; el APK/AAB y los FPS reales requieren validación en Android.

## Pruebas recomendadas

1. Reclutar varios compañeros armados y desarmados y probar amenazas visibles y detrás de muros.
2. Probar con hordas de 100, 500 y más zombis para medir el tiempo de `updNpcs()` y los FPS.
3. Confirmar que compañeros no disparan a través de paredes y que los NPC desarmados siguen huyendo de amenazas cercanas.
4. Guardar/cargar partidas y probar el multijugador como anfitrión e invitado.
