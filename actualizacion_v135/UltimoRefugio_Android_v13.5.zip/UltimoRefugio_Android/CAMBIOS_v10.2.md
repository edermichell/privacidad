# Último Refugio Android 10.2

## Objetivo

Mejorar la respuesta del combate y reducir asignaciones temporales durante los disparos, conservando el pixel art, las mecánicas existentes, el multijugador y los guardados.

## Cambios incluidos

- **Combate cuerpo a cuerpo con línea de visión:** la asistencia de apuntado, la selección de objetivo, el impacto real, los golpes a fauna/NPC y el empujón comprueban que el blanco sea alcanzable. Evita pegar o empujar a través de paredes, árboles y puertas cerradas.
- **Revalidación al impactar:** si el zombi se desplaza detrás de un obstáculo durante la preparación del golpe, el impacto ya no atraviesa el obstáculo. Se conserva la prioridad del objetivo fijado si continúa visible y dentro del alcance.
- **Disparos con menos asignaciones:** sustituye `Z.concat(NPCS, FA)` por un escaneo secuencial de las listas originales usando un estado reutilizable. Conserva el mismo cono de dispersión, alcance, selección del blanco y cálculo del daño.
- **Versión Android:** `versionCode` 94 y `versionName` 10.2. Se conserva el `applicationId`.

## Compatibilidad y guardados

No se modificaron `SAVEKEY`, `localStorage`, los formatos de serialización, las tablas de objetos, las reglas de carga, los identificadores de productos ni el contenido de las partidas. No se añadieron migraciones de guardado.

## Validaciones realizadas

- Comprobación de sintaxis JavaScript con Node.js (`node --check`) sobre los scripts embebidos.
- Comprobación de estructura e integridad del ZIP.
- Verificación de que el identificador de aplicación, las claves de guardado y los recursos originales permanecen intactos.
- Comparación de archivos: fuera del HTML principal, versión Gradle y documentación, los archivos del paquete se mantienen iguales a 10.1.
- No se ejecutó compilación Android ni prueba física en dispositivos; el APK/AAB debe compilarse y probarse antes de publicar.

## Pruebas recomendadas

1. Golpear zombis detrás de paredes, árboles, puertas cerradas y ventanas con tablas: el golpe debe bloquearse.
2. Golpear zombis que se mueven detrás de una pared durante la animación: el impacto debe fallar.
3. Golpear zombis y fauna a corta distancia, incluyendo objetivos derribados y armas de distinto alcance.
4. Disparar con pistola, escopeta, subfusil y ballesta; comprobar dispersión, alcance, munición y estelas.
5. Probar interiores, plantas altas/azoteas, guardados, carga y multijugador.
