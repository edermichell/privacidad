# Último Refugio 12.3

## Objetivo

La 12.3 responde a dos problemas concretos: animales que se atascan en paredes/muebles (incluidos armarios) y coste gráfico elevado en escenas con muchos civiles y zombis. Se conserva el estilo pixel art y no se cambia el formato de las partidas.

## 1. Navegación y colisiones de fauna

- Se añade una comprobación de ocupación que considera el radio aproximado de cada animal, en lugar de tratarlo como un punto.
- Se valida el movimiento en pasos cortos de hasta 0.075 casillas y se comprueba el contacto con el mapa sólido y los vehículos.
- Cuando la dirección solicitada está bloqueada, se prueban desvíos laterales y, como último recurso, deslizamiento por un solo eje para evitar atravesar esquinas.
- Se aplica a fauna del mapa (conejos, ciervos, gallinas, palomas y ardillas), gatos, ratas y perro.
- Se incorpora una recuperación local para animales que ya aparecían dentro de una pared/mueble por una posición de spawn o partida anterior: hasta 0.48 casillas si solamente rozan un borde; hasta 1.04 casillas si el centro está en una baldosa sólida. Esta recuperación es excepcional y no forma parte del movimiento normal.
- Se añade al diagnóstico el número de animales activos/atascados y los bloqueos, desvíos y ajustes realizados.
- Se conecta `updCats(dt)` al ciclo normal de actualización. La función existía, pero no estaba conectada al tick de mundo en la base 12.2.

## 2. Rendimiento y gráficos

- Se aplica nivel de detalle de animación a zombis y NPC según distancia: animación completa cerca; 8 fases a distancia media; 4 fases en distancia lejana y 2 fases a más de 30 casillas. En calidad baja se reduce la animación lejana, manteniendo completa la zona cercana.
- Se actualiza el orden LRU de sprites usados cada 0.9 segundos en lugar de 2 segundos para que las apariencias activas recientes tengan más posibilidades de permanecer en la caché cuando se llena.
- No se aumenta el presupuesto máximo de caché gráfica. En la medición 12.2 ya se ocupaban aproximadamente 68.6 MiB teóricos de 68.7 MiB. La prioridad es reducir variantes activas y expulsiones antes de elevar el consumo de memoria.
- No se modifican daño, velocidad de combate, reglas de zombis, construcción, inventarios ni multijugador.

## 3. Guardados y compatibilidad

- Se mantienen las claves de almacenamiento y las funciones de guardado/carga de versiones anteriores.
- Los estados de navegación y contadores ` _v123...` son temporales y no se serializan.
- Se conserva el identificador original de la aplicación.
- Android: `versionName 12.3`, `versionCode 115`.

## 4. Verificaciones realizadas

- `node --check` en los dos bloques JavaScript embebidos.
- Los cuatro XML del proyecto se parsean correctamente.
- Prueba aislada de colisiones y recuperación con conejo, ciervo, gallina, gato, rata y perro; se comprueba que no terminen solapando paredes/armarios.
- Prueba de recuperación de un animal ubicado en el centro de un mueble; termina en una posición transitable dentro del radio local permitido.
- Prueba de inicio de partida en Chromium, apertura/cierre del diagnóstico F2 y copia del informe.
- Prueba en un mapa generado por el juego: se coloca un gato de prueba en una baldosa de armario y se verifica que la rutina de mantenimiento lo desplaza a una posición transitable.
- Integridad del ZIP comprobada.

## 5. Pendiente

No se compiló APK/AAB ni se midió FPS en un dispositivo Android físico porque este entorno no dispone de Android SDK/Gradle. La mejora de rendimiento es una optimización de código; su impacto real debe medirse con el mismo escenario de campamento y el informe F2 de la 12.3.
