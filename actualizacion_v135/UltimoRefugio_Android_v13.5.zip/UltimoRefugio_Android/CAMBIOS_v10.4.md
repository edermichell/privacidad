# Último Refugio Android 10.4

## Objetivo

Mejorar la respuesta de los supervivientes y reducir el coste de las consultas de amenaza cuando hay hordas numerosas, conservando el pixel art, el equilibrio de rendimiento y los sistemas existentes.

## Cambios incluidos

- **Índice espacial para la IA de NPC:** se construye una cuadrícula temporal de zombis en celdas de 8×8 tiles una vez por actualización del mundo. Los buckets y el mapa se reutilizan para evitar crear estructuras completas en cada consulta.
- **Escaneo de amenazas más eficiente:** los compañeros consultan únicamente las celdas cercanas para localizar al zombi más próximo, en lugar de recorrer toda la lista mundial.
- **Atracción y mordiscos localizados:** la atracción de zombis por NPC y los ataques contra supervivientes usan el mismo índice, manteniendo los filtros de distancia, estado y línea de visión existentes.
- **Compatibilidad de comportamiento:** el orden de actualización de NPC, distancias, probabilidades de daño, tiempos de ataque, diálogos, rutas y reglas de combate no se modifican intencionalmente.
- **Versión Android:** `versionCode` 96 y `versionName` 10.4. Se conserva el `applicationId`.

## Compatibilidad y guardados

No se modificaron `SAVEKEY`, `OPTKEY`, `localStorage`, serialización de partidas, inventario, objetos, construcción, vehículos, contenido de eventos ni protocolo de multijugador. El índice se reconstruye durante la simulación y no se guarda, por lo que no requiere migraciones.

## Validaciones realizadas

- Comprobación sintáctica de todos los bloques JavaScript embebidos con Node.js.
- Prueba diferencial determinista con 2,400 zombis y 60 posiciones de NPC: el objetivo más cercano coincide con el escaneo completo original.
- Comprobación de parseo de los XML de Android.
- Verificación del ZIP y del contenido esencial del proyecto.
- Verificación de `applicationId`, `versionCode`, `versionName`, `SAVEKEY` y `OPTKEY`.
- Comparación de archivos para confirmar que el cambio queda limitado al HTML del juego, versión Gradle y este registro.
- No se ejecutó compilación Android ni prueba física; el APK/AAB y el comportamiento deben verificarse en dispositivos antes de publicar.

## Pruebas recomendadas

1. Reclutar varios compañeros y atraer una horda grande; verificar que prioricen amenazas cercanas.
2. Observar NPC cerca de paredes, puertas y vallas; deben seguir respetando las comprobaciones de línea de visión.
3. Probar ataques contra NPC y confirmar que el daño y los tiempos no cambian.
4. Probar multijugador como anfitrión e invitado, junto con guardado/carga.
5. Comparar FPS y tiempos de actualización con numerosos zombis y NPC en dispositivos modestos y potentes.
