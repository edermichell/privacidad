# Publicar Último Refugio en Google Play con monetización

Todo el código de anuncios y compras ya está dentro del proyecto. Solo faltan **tus cuentas e IDs reales**.
Desde la v103 **AdMob está eliminado**: los anuncios son **solo de Unity Ads y REALES por defecto** (no hay anuncios de prueba de Google).

## 1. Cuentas necesarias
1. **Google Play Console** (pago único de 25 USD): https://play.google.com/console
2. **Unity** (gratis): https://cloud.unity.com → Monetization → Ads (Game ID y bloques del proyecto Android).
3. *(Solo si quieres anuncios en EEE / Reino Unido / Suiza)* una cuenta de **AdMob** gratuita, **únicamente** para crear el mensaje RGPD y obtener el ID de app que pide el formulario de consentimiento (UMP). No se sirven anuncios de AdMob.
4. Perfil de pagos / fiscal en Play Console y Unity (para cobrar).

## 2. Poner los IDs reales (sin tocar código)
Los IDs ya NO están en `strings.xml`: se leen de **secretos de GitHub** al compilar con el tipo `publicar`
(Settings ▸ Secrets and variables ▸ Actions ▸ New repository secret). Todos son opcionales; si falta alguno se usa el valor por defecto.
| Secreto | Qué poner |
|---|---|
| `UNITY_GAME_ID` / `UNITY_REWARDED` / `UNITY_INTERSTITIAL` | Game ID y bloques de tu proyecto en Unity (por defecto `800423692`, `BP_Rewarded_Android`, `BP_Interstitial_Android`) |
| `UMP_APP_ID` | ID de app de AdMob (`ca-app-pub-XXXX~YYYY`), solo para el formulario RGPD. Sin él, en EEE/Reino Unido/Suiza no aparece el formulario y **no se muestran anuncios**; en el resto del mundo funcionan igual |
| `PRIVACY_URL` | URL pública de tu política de privacidad (ver paso 5) |
| `PLAY_LICENSE_KEY` | (opcional) clave de licencia de Play Console ▸ Monetización ▸ Licencias |

Al compilar `publicar` sin secretos, el registro de la compilación muestra un aviso con lo que falta.

⚠ Nunca hagas clic en tus propios anuncios reales: Unity puede suspender tu cuenta. Para probar usa `UNITY_TEST_MODE=true` o registra tu dispositivo como de prueba en el Dashboard de Unity.

### 2b. Proveedor de anuncios
El secreto `ADS_PROVIDER` elige el proveedor:
| Valor de `ADS_PROVIDER` | Qué hace |
|---|---|
| *(vacío)* o `unity` | Usa **Unity Ads** (por defecto): anuncios reales |
| `none` | **Sin anuncios** (no se carga ningún SDK de anuncios ni se pide consentimiento; los botones de "ver anuncio" avisan que no hay anuncios) |

**`UNITY_TEST_MODE`** (v83b): vacío o `false` = anuncios **REALES** de Unity (por defecto, generan ingresos); `true` = anuncios de PRUEBA.
(Para usar este secreto, el archivo `.github/workflows/build.yml` del repo debe ser el de esta versión; si no lo cambias, funcionan los valores por defecto.)
⚠ No pulses tus propios anuncios reales. Declara también a Unity en *Seguridad de los datos* (ver paso 6).

## 3. Crear los productos de compra (Play Console → Monetización → Productos → Productos integrados)
Los ID deben ser **exactamente** estos:
| ID del producto | Tipo | Nombre sugerido | Precio sugerido (MXN) |
|---|---|---|---|
| `noads` | Se compra una vez | Sin anuncios | 29 |
| `skins` | Se compra una vez | Trajes premium | 39 |
| `vip` | Se compra una vez | Pack Fundador | 79 |
| `crates5` | **Consumible** (se puede comprar varias veces) | 5 cajas de suministros | 19 |

En Play Console, "se compra una vez" = *no consumible*; `crates5` se consume en el código para poder repetir la compra.
Activa cada producto. Los precios se muestran en la moneda local automáticamente.

## 4. Firmar y subir
1. Android Studio → **Build ▸ Generate Signed Bundle / APK ▸ Android App Bundle** (guarda tu `.jks` y contraseñas, no las pierdas).
2. Play Console → crea la app → **Pruebas internas** → sube el `.aab`. Agrega tu correo como probador y prueba:
   - que se vean anuncios, el revivir con anuncio y las cajas gratis,
   - una compra de prueba (agrega tu correo en *Configuración ▸ Pruebas de licencia* para comprar sin cobro),
   - restaurar compras (Tienda → Restaurar compras).
3. **Tu cuenta es personal**: antes de producción debes hacer una **prueba cerrada con al menos 12 testers que se mantengan inscritos 14 días seguidos**. Pasos: Play Console → Pruebas → Pruebas cerradas → crea la pista, sube el `.aab`, agrega una lista de correos (Gmail) de 12+ testers, comparte el enlace de inscripción y pídeles que instalen y abran la app; cuando se cumplan los 14 días aparece el botón "Solicitar acceso a producción" (Google responde en ~7 días). Consejo: reúne 15–20 testers por si alguno se sale.
4. Mientras Unity activa el relleno de tu proyecto (puede tardar horas o días), la app funciona igual sin anuncios; revisa *Statistics* en el Dashboard de Unity.

## 5. Política de privacidad (obligatoria)
- El archivo `privacy.html` (en esta carpeta) ya está redactado. El correo de contacto ya es impulsocapitalciudadano@gmail.com. Súbelo a un sitio público (por ejemplo GitHub Pages o tu web) y pon esa URL en el secreto `PRIVACY_URL` y en Play Console → *Contenido de la app ▸ Política de privacidad*.

**Cómo hospedarla gratis en 3 minutos (GitHub Pages, desde el iPhone/Safari):**
1. github.com ▸ New repository ▸ nombre `privacidad` ▸ **Public** ▸ Create.
2. Add file ▸ Upload files ▸ sube `privacy.html` y **renómbralo a `index.html`** ▸ Commit.
3. Settings ▸ Pages ▸ Source: *Deploy from a branch* ▸ rama `main` / carpeta `/ (root)` ▸ Save.
4. Tras ~1 minuto tu URL es `https://TU-USUARIO.github.io/privacidad/` → ábrela para comprobar que carga y úsala en `PRIVACY_URL` y en Play Console.

## 6. Formularios de "Contenido de la app" en Play Console
- **Anuncios:** sí, la app contiene anuncios.
- **Público objetivo:** 13+ (mejor **18+** si quieres evitar restricciones). NO marques "dirigido a niños" (el código no activa modo niños en Unity).
- **Clasificación de contenido (IARC):** violencia de fantasía contra zombis, armas; sin sangre realista extrema → normalmente sale Teen/PEGI 12–16.
- **Seguridad de los datos:** declara que se recopila *ID de dispositivo o de publicidad* (lo usa Unity Ads para anuncios), además de *interacciones con la app/anuncios* y *dirección IP aproximada / diagnóstico* que tratan estas redes y *compras* (Google Play). No hay cuentas, ni ubicación, ni datos personales propios. Los datos se **comparten** con terceros (Unity y Google) para publicidad; no se venden. La política de privacidad actualizada (v83) ya menciona a Unity: súbela de nuevo a tu URL pública.
- **ID de publicidad:** declara que la app lo usa para publicidad (el permiso AD_ID ya está en el manifiesto).
- **Compras dentro de la app:** marca "contiene compras" y las cajas: indica que son objetos de utilidad.

## 7. Qué hace la monetización (por si te preguntan)
- Juego **gratis y completo**; nada obligatorio de pagar.
- **Anuncio con recompensa (opcional):** revivir una vez por partida, +1 caja (máx. 3 al día, con 1 min de espera).
- **Anuncio intersticial:** solo al terminar una partida (nunca durante el juego), máximo 1 cada 2.5 minutos y desde la 3.ª partida. Se quita con *Sin anuncios*.
- **Consentimiento (UMP):** formulario de Google en las regiones que lo exigen (se pasa a Unity); el jugador puede cambiarlo en Tienda → Privacidad y anuncios.
- **Compras:** sin anuncios, trajes (solo estética), Pack Fundador (sin anuncios + trajes + traje dorado + 3 cajas + 1 revivir gratis por partida) y cajas de suministros (objetos modestos: comida, medicina, munición).
- Las compras se **restauran** al reinstalar (Play Billing) y el estado de compra se sincroniza con Google Play cada vez que abres la app.

## 8. Modo demo
Abre `index.html` en un navegador y entrarás en **modo demo**: los anuncios son una pantalla de prueba de 5 s y las compras se simulan gratis. Sirve para probar todo el flujo sin Android.

## 9. Mejoras recomendadas más adelante
- Verificar compras en un servidor (evita que alguien edite los datos locales del juego para regalarse productos).
- Iconos y capturas de pantalla (mínimo 2) y gráfico de funciones 1024×500 para la ficha de la tienda.
