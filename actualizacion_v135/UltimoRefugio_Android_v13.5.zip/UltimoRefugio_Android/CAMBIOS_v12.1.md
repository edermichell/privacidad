# Último Refugio Android 12.1

## Objetivo

Mejorar el diagnóstico del renderizado y el uso del margen entre fotogramas, tomando como referencia las mediciones compartidas de la versión 12.0. Se conserva el estilo pixel art y no se cambian las reglas de juego.

## Cambios

### 1. Diagnóstico granular del renderizado

Cuando el panel de diagnóstico está abierto, el render registra por separado los tiempos de preparación, terreno, suelo, mundo, efectos del mundo, iluminación y composición final. También cuenta chunks, tiles, entradas de dibujo, techos y fuentes de luz. El muestreo se desactiva cuando el panel está cerrado para evitar el coste adicional de las mediciones.

### 2. Separación del intervalo rAF y el trabajo JavaScript

El informe muestra el intervalo real entre callbacks de `requestAnimationFrame`, el tiempo de trabajo JavaScript y una diferencia estimada (`rAF - JS`). Esa diferencia sirve como pista para investigar el compositor del navegador/WebView, GPU, frecuencia de pantalla o ahorro energético; **no es una medición directa del tiempo de GPU**.

El FPS efectivo del informe se calcula con la misma ventana móvil de intervalos rAF utilizada por las estadísticas. Se mantiene también el contador interno corto para poder compararlos.

### 3. Planificador de trabajo diferido

El criterio anterior podía dejar tareas pendientes cuando el trabajo principal rondaba los 11 ms. Ahora se estima el margen del intervalo rAF y, si hay sprites/terreno/techos pendientes, se permite una porción pequeña de trabajo diferido (hasta 2.2 ms), reservando al menos 3.2 ms de margen y evitando iniciar trabajo tras intervalos largos.

Este margen es una heurística de planificación, no una garantía de tiempo libre de GPU. El panel informa cuántas veces se ejecutó o aplazó el trabajo diferido.

### 4. Menos asignaciones por fotograma

El cálculo de los límites de cámara para el recorrido del terreno ya no crea cuatro arreglos de coordenadas temporales y un arreglo contenedor por fotograma; calcula las cuatro esquinas con escalares.

### 5. Caché gráfica más transparente

El informe muestra tasa de fallos, expulsiones y una estimación teórica del tamaño RGBA de las superficies en caché. La cifra MiB es una aproximación de memoria de píxeles, no memoria GPU medida ni memoria total del proceso. No se aumenta el límite de caché en esta versión: primero se recopilan más datos de expulsiones y regeneración.

## Compatibilidad

- Se conserva el `applicationId`: `com.impulso.ultimorefugio`.
- `versionCode`: `113`.
- `versionName`: `12.1`.
- Se conservan las claves `ultimo_refugio_v3` y `ultimo_refugio_opt`.
- No se cambian las funciones ni el formato de guardado.
- No se modifican las reglas de daño, IA, movimiento, combate, construcción o multijugador.
- Los archivos nativos Android y recursos del proyecto se mantienen iguales a 12.0; cambian el HTML principal, el número de versión y este registro.

## Validaciones

- Sintaxis JavaScript comprobada con Node.
- Apertura del cliente en Chromium headless.
- Inicio de partida, apertura del panel con F2 y cierre con Escape.
- Prueba del informe con métricas sintéticas, incluyendo pausas largas y picos aislados.
- XML Android parseados correctamente.
- Comparación de archivos con 12.0: únicamente cambian `app/build.gradle`, `app/src/main/assets/index.html` y este registro.

## Pendiente

No se ha compilado APK/AAB ni medido el rendimiento en un teléfono Android. Este entorno no dispone de Android SDK ni Gradle. Los resultados de Chromium sirven para validar arranque e instrumentación, no para afirmar mejoras de FPS en el dispositivo del jugador.
