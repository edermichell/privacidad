# Último Refugio 13.2 — acabado pixel art e iluminación de superficies

## Objetivo
Mejorar la separación visual de los personajes y la lectura de superficies mojadas sin sustituir los sprites originales, sin introducir texturas externas pesadas y sin alterar la simulación ni los guardados.

## Cambios gráficos

- Se añade una luz de borde pixelada cálida para el jugador, NPC y zombis cercanos durante condiciones de luz solar.
- El borde se genera desde la silueta alfa del sprite original, desplazando su máscara un píxel lógico hacia el lado superior/izquierdo, y se dibuja detrás del sprite principal.
- El efecto se omite en calidad baja, durante la noche y en personajes lejanos. Las poses inclinadas conservan su dibujo previo para evitar desalineación.
- Los overlays se almacenan en una caché LRU limitada por presupuesto aproximado de 4 MiB (mínimo 16 y máximo 64 sprites), por lo que las variantes antiguas pueden liberarse.
- Se añaden pequeños brillos especulares deterministas al asfalto mojado y a algunas aceras. Se hornean en el overlay `chunkWet` existente y no añaden operaciones por fotograma después de crear el chunk.

## Diagnóstico

- F2 muestra cantidad de rim lights dibujados, overlays creados/reutilizados, tamaño de caché y expulsiones.
- Los contadores se pueden reiniciar junto al resto del diagnóstico.

## Compatibilidad y seguridad

- No se añaden propiedades a jugadores, NPC, zombis, fauna o estructuras.
- No se modifican `SAVEKEY`, `OPTKEY`, `baseSave`, `baseLoad`, recetas, daño, IA, movimiento ni protocolos de red.
- Se conserva la inicialización temprana de `TIME` de la corrección 12.4.1 y el manejador de errores de arranque.
- Los sprites base siguen intactos; los overlays son derivados temporales y tienen una caché acotada.
- HTML de prueba copiado byte por byte desde `app/src/main/assets/index.html`.
- `versionName 13.2`, `versionCode 125`.

## Validaciones

- Ambos bloques JavaScript pasan `node --check`.
- Los cuatro XML del proyecto Android se parsean correctamente.
- Se verificó que la caché de rim lights respeta su límite estimado de memoria en RS2/RS3/RS4.
- Se verificó la presencia de los filtros de calidad/distancia y de la generación de brillos exclusivamente en `chunkWet`.
- Se comprobó que las claves y funciones de guardado mantienen las mismas definiciones que 13.1.
- No se completó una prueba de arranque en Chromium: el proceso Chromium disponible en este entorno no termina ni siquiera con `about:blank`. No se presenta como prueba superada.
- No se compiló APK/AAB: este entorno no dispone de Android SDK ni Gradle instalados. Tampoco se midió FPS en un dispositivo físico.
