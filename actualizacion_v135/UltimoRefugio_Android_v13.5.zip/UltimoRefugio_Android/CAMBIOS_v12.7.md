# Último Refugio 12.7 — cambios técnicos

## Objetivo

Reducir el coste de ordenar las entidades por profundidad dentro de cada diagonal isométrica, sin cambiar el orden de dibujo, las posiciones ni las reglas de simulación. También se corrigió la captura de teclas del panel de diagnóstico durante la introducción.

## Cambios

### Ordenamiento adaptativo de buckets

- Se añadió `sortDrawBucket127()`.
- Primero comprueba si cada bucket ya está ordenado por `y`; cuando lo está, omite el ordenamiento.
- Para buckets de hasta 16 entradas utiliza insertion sort estable, adecuado para listas pequeñas.
- Para buckets mayores que están desordenados, conserva el `Array.sort()` nativo con el comparador original.
- El insertion sort desplaza únicamente cuando `a[j].y > y`, por lo que los empates mantienen su orden de inserción.
- No se alteran las coordenadas, profundidades, entidades ni reglas de colisión o IA.

### Diagnóstico F2

Se añadieron contadores al informe y al panel:

- Buckets comprobados.
- Buckets ya ordenados (sin reordenamiento).
- Buckets ordenados mediante insertion sort.
- Buckets ordenados mediante `Array.sort()` nativo.
- Tamaño máximo de bucket observado.

El tiempo sigue incluido en la fase `bucketSort` para permitir la comparación con informes anteriores.

### Corrección de teclado del diagnóstico

- La introducción inicial capturaba todas las teclas antes de que llegaran al manejador del diagnóstico.
- Ahora F2 puede abrir el panel durante la introducción.
- Escape cierra el panel cuando está abierto, sin saltar accidentalmente la introducción.
- Se conserva la navegación normal de la introducción para las demás teclas.

### Compatibilidad y versión

- `versionName`: `12.7`.
- `versionCode`: `120`.
- `TIME` continúa inicializada antes de `humanSprite()`, conservando el hotfix de pantalla negra 12.4.1.
- `SAVEKEY`, `baseSave()` y `baseLoad()` son idénticos a la versión 12.6.
- No se modificaron los formatos de guardado, el identificador de aplicación ni los archivos nativos de Android.

## Pruebas realizadas

- Los dos bloques JavaScript embebidos pasan `node --check`.
- 250,000 buckets aleatorios se compararon con `Array.sort()` nativo; coincidieron las referencias y el orden estable, incluidos los empates de profundidad.
- Microbenchmark sintético Node/V8 (no equivale a FPS del juego ni a medición en teléfono):
  - 20,000 buckets de 2–8 entradas: `Array.sort` 18.80 ms; adaptativo 2.73 ms.
  - 20,000 buckets de 9–16 entradas: `Array.sort` 25.18 ms; adaptativo 3.11 ms.
  - 10,000 buckets de 17–40 entradas: `Array.sort` 21.53 ms; adaptativo 13.06 ms.
  - Los resultados dependen del navegador/motor JS y de la distribución de los buckets; no deben interpretarse como una mejora porcentual de FPS.
- Prueba de Chromium mediante HTML cargado en memoria: menú visible, nueva partida iniciada (`STATE=play`), panel diagnóstico abierto, informe 12.7 y contadores `Buckets sort` presentes, Escape cierra el panel y no se registraron errores JavaScript.
- Se verificó la corrección de F2/Escape durante la introducción.
- Los cuatro XML Android pasan parseo.
- El `index.html` incluido en el proyecto Android es idéntico al HTML independiente de prueba.

## Pendiente

- No se compiló APK/AAB: este entorno no dispone de Android SDK/Gradle ejecutable.
- No se midió el FPS en un dispositivo Android. La mejora real debe medirse con una escena comparable a las pruebas 12.1/12.2 y el panel F2 activo unos 20 segundos.
