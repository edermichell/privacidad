# Publicar Último Refugio en Google Play con monetización

Todo el código de anuncios y compras ya está dentro del proyecto. Solo faltan **tus cuentas e IDs reales**.
Mientras uses los IDs de prueba (los que vienen puestos) verás anuncios de prueba y NO ganarás dinero.

## 1. Cuentas necesarias
1. **Google Play Console** (pago único de 25 USD): https://play.google.com/console
2. **AdMob** (gratis): https://admob.google.com → crea una app "Android" con el paquete `com.impulso.ultimorefugio`.
3. Perfil de pagos / fiscal en Play Console y AdMob (para cobrar).

## 2. Poner los IDs reales (sin tocar código)
Los IDs ya NO están en `strings.xml`: se leen de **secretos de GitHub** al compilar con el tipo `publicar`
(Settings ▸ Secrets and variables ▸ Actions ▸ New repository secret). Todos son opcionales; si falta alguno se usa el de prueba.
| Secreto | Qué poner |
|---|---|
| `ADMOB_APP_ID` | ID de la app de AdMob (`ca-app-pub-XXXX~YYYY`) |
| `ADMOB_REWARDED` | ID de bloque **Con recompensa** (crea uno en AdMob) |
| `ADMOB_INTERSTITIAL` | ID de bloque **Intersticial** |
| `PRIVACY_URL` | URL pública de tu política de privacidad (ver paso 5) |
| `PLAY_LICENSE_KEY` | (opcional) clave de licencia de Play Console ▸ Monetización ▸ Licencias |

Para pruebas internas/cerradas **puedes dejar todo vacío**: salen anuncios de prueba y es lo recomendado para los testers.
Al compilar `publicar` sin secretos, el registro de la compilación muestra un aviso con lo que falta.

⚠ Nunca hagas clic en tus propios anuncios reales: AdMob puede suspender tu cuenta. Para probar con IDs reales agrega tu dispositivo como "dispositivo de prueba" en AdMob.

### 2b. Anuncios con Unity Ads (v83) — alternativa a AdMob
Desde la v83 la app trae **Unity Ads** y elige el proveedor con el secreto `ADS_PROVIDER`:
| Valor de `ADS_PROVIDER` | Qué hace |
|---|---|
| *(vacío)* o `unity` | Usa **Unity Ads** (por defecto): Game ID `800423692`, bloques `BP_Rewarded_Android` y `BP_Interstitial_Android` |
| `admob` | Usa AdMob (IDs `ADMOB_*` del paso 2) |
| `none` | **Sin anuncios** (no se carga ningún SDK de anuncios ni se pide consentimiento; los botones de "ver anuncio" avisan que no hay anuncios) |

Secretos opcionales de Unity (si están vacíos se usan los de arriba): `UNITY_GAME_ID`, `UNITY_REWARDED`, `UNITY_INTERSTITIAL`.
**`UNITY_TEST_MODE`** (v83b): vacío o `false` = anuncios **REALES** de Unity (por defecto, generan ingresos); `true` = anuncios de PRUEBA.
(Para usar este secreto, el archivo `.github/workflows/build.yml` del repo debe ser el de esta versión; si no lo cambias, funcionan los valores por defecto.)
⚠ No pulses tus propios anuncios reales. Declara también a Unity en *Seguridad de los datos* (ver paso 6).

## 3. Crear los productos de compra (Play Console → Monetización → Productos → Productos integrados)
Los ID deben ser **exactamente** estos:
| ID del producto | Tipo | Nombre sugerido | Precio sugerido (MXN) |
|---|---|---|---|
| `noads` | Se compra una vez | Sin anuncios | 29 |
| `skins` | Se compra una vez | Trajes premium | 39 |
| `vip` | Se compra una vez | Pack Fundador | 79 |
| `crates5` | **Consumible** (se puede comprar varias veces) | 5 cajas de suministros | 19 |

En Play Console, "se compra una vez" = *no consumible*; `crates5` se consume en el código para poder repetir la compra.
Activa cada producto. Los precios se muestran en la moneda local automáticamente.

## 4. Firmar y subir
1. Android Studio → **Build ▸ Generate Signed Bundle / APK ▸ Android App Bundle** (guarda tu `.jks` y contraseñas, no las pierdas).
2. Play Console → crea la app → **Pruebas internas** → sube el `.aab`. Agrega tu correo como probador y prueba:
   - que se vean anuncios, el revivir con anuncio y las cajas gratis,
   - una compra de prueba (agrega tu correo en *Configuración ▸ Pruebas de licencia* para comprar sin cobro),
   - restaurar compras (Tienda → Restaurar compras).
3. **Tu cuenta es personal**: antes de producción debes hacer una **prueba cerrada con al menos 12 testers que se mantengan inscritos 14 días seguidos**. Pasos: Play Console → Pruebas → Pruebas cerradas → crea la pista, sube el `.aab`, agrega una lista de correos (Gmail) de 12+ testers, comparte el enlace de inscripción y pídeles que instalen y abran la app; cuando se cumplan los 14 días aparece el botón "Solicitar acceso a producción" (Google responde en ~7 días). Consejo: reúne 15–20 testers por si alguno se sale.
4. Mientras AdMob verifica tu cuenta, deja los IDs de prueba: la app funciona igual y solo agregas los 3 secretos `ADMOB_*` al recibir la aprobación y compilas de nuevo `publicar` (sube el versionCode).

## 5. Política de privacidad (obligatoria)
- El archivo `privacy.html` (en esta carpeta) ya está redactado. El correo de contacto ya es impulsocapitalciudadano@gmail.com. Súbelo a un sitio público (por ejemplo GitHub Pages o tu web) y pon esa URL en el secreto `PRIVACY_URL` y en Play Console → *Contenido de la app ▸ Política de privacidad*.

**Cómo hospedarla gratis en 3 minutos (GitHub Pages, desde el iPhone/Safari):**
1. github.com ▸ New repository ▸ nombre `privacidad` ▸ **Public** ▸ Create.
2. Add file ▸ Upload files ▸ sube `privacy.html` y **renómbralo a `index.html`** ▸ Commit.
3. Settings ▸ Pages ▸ Source: *Deploy from a branch* ▸ rama `main` / carpeta `/ (root)` ▸ Save.
4. Tras ~1 minuto tu URL es `https://TU-USUARIO.github.io/privacidad/` → ábrela para comprobar que carga y úsala en `PRIVACY_URL` y en Play Console.

## 6. Formularios de "Contenido de la app" en Play Console
- **Anuncios:** sí, la app contiene anuncios.
- **Público objetivo:** 13+ (mejor **18+** si quieres evitar restricciones). NO marques "dirigido a niños" (el código ya envía "no dirigido a menores" a AdMob y no activa modo niños en Unity).
- **Clasificación de contenido (IARC):** violencia de fantasía contra zombis, armas; sin sangre realista extrema → normalmente sale Teen/PEGI 12–16.
- **Seguridad de los datos:** declara que se recopila *ID de dispositivo o de publicidad* (lo usan Unity Ads / AdMob para anuncios), además de *interacciones con la app/anuncios* y *dirección IP aproximada / diagnóstico* que tratan estas redes y *compras* (Google Play). No hay cuentas, ni ubicación, ni datos personales propios. Los datos se **comparten** con terceros (Unity y Google) para publicidad; no se venden. La política de privacidad actualizada (v83) ya menciona a Unity: súbela de nuevo a tu URL pública.
- **ID de publicidad:** declara que la app lo usa para publicidad (el permiso AD_ID ya está en el manifiesto).
- **Compras dentro de la app:** marca "contiene compras" y las cajas: indica que son objetos de utilidad.

## 7. Qué hace la monetización (por si te preguntan)
- Juego **gratis y completo**; nada obligatorio de pagar.
- **Anuncio con recompensa (opcional):** revivir una vez por partida, +1 caja (máx. 3 al día, con 1 min de espera).
- **Anuncio intersticial:** solo al terminar una partida (nunca durante el juego), máximo 1 cada 2.5 minutos y desde la 3.ª partida. Se quita con *Sin anuncios*.
- **Consentimiento (UMP):** formulario de Google en las regiones que lo exigen; el jugador puede cambiarlo en Tienda → Privacidad y anuncios.
- **Compras:** sin anuncios, trajes (solo estética), Pack Fundador (sin anuncios + trajes + traje dorado + 3 cajas + 1 revivir gratis por partida) y cajas de suministros (objetos modestos: comida, medicina, munición).
- Las compras se **restauran** al reinstalar (Play Billing) y el estado de compra se sincroniza con Google Play cada vez que abres la app.

## 8. Modo demo
Abre `index.html` en un navegador y entrarás en **modo demo**: los anuncios son una pantalla de prueba de 5 s y las compras se simulan gratis. Sirve para probar todo el flujo sin Android.

## 9. Mejoras recomendadas más adelante
- Verificar compras en un servidor (evita que alguien edite los datos locales del juego para regalarse productos).
- Iconos y capturas de pantalla (mínimo 2) y gráfico de funciones 1024×500 para la ficha de la tienda.
