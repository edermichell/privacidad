# Último Refugio v14.0.1 (versionCode 138) — arreglo mínimo sobre la 14.0

Única corrección: en las salas del multijugador no se veía a los demás jugadores; cada jugador cercano se dibujaba como el «Anfitrión» del servidor, quieto en el punto de entrada.

Cambios respecto a la 14.0 aprobada (versionCode 137):
- `app/src/main/assets/index.html`: la lista de dibujo ya no descarta al jugador remoto (se pinta cada uno con sus datos); el anfitrión del servidor no aparece en el mapa; la app avisa al servidor de que ya trae el arreglo; etiqueta «v14.0.1».
- `app/build.gradle`: `versionCode 138`, `versionName "14.0.1"`.
- **Java, recursos, permisos y dependencias: idénticos a la 14.0.**

Funciona con el servidor tal como lo tengas (antiguo o nuevo).
