# Último Refugio v14.0.2 (versionCode 139) — arreglos de multijugador sobre la 14.0

Respecto a la 14.0 aprobada (versionCode 137):
1. **Jugadores visibles en las salas** (arreglo de la 14.0.1): cada jugador se dibuja en su sitio, con su aspecto y su nombre; antes se dibujaba siempre el «Anfitrión» del servidor.
2. **Golpes y disparos de los demás a la vista:** cada golpe y cada disparo viaja como un evento y se reproduce completo (animación, arco, estela de la bala, fogonazo, casquillo y sonido con la distancia). Necesita también el kit nuevo del servidor.
3. **Salas del servidor sin «anfitrión»:** los textos ya no hablan de «anfitrión» ni de «tu compañero».

Archivos cambiados: `app/src/main/assets/index.html` y `app/build.gradle` (`versionCode 139`, `versionName "14.0.2"`). **Java, recursos, permisos y dependencias: idénticos a la 14.0.**
